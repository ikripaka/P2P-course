package com.shpp.cs.namesurfer;

/*
 * File: NameSurferGraph.java
 * ---------------------------
 * This class represents the canvas on which the graph of
 * names is drawn. This class is responsible for updating
 * (redrawing) the graphs whenever the list of entries changes
 * or the window is resized.
 */

import acm.graphics.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;

public class NameSurferGraph extends GCanvas
        implements NameSurferConstants, ComponentListener {

    /**
     * Creates a new NameSurferGraph object that displays the data.
     */
    private ArrayList<Object> allGraphElements;
    private ArrayList<String> names;
    private HashMap<String, ArrayList<Integer>> popularityDataHashMap;
    private Color[] graphColors = {Color.BLUE, Color.RED, Color.MAGENTA, Color.BLACK};


    public NameSurferGraph() {
        addComponentListener(this);
        allGraphElements = new ArrayList<>();
        popularityDataHashMap = new HashMap<>();
        names = new ArrayList<>();
        update();
    }


    /**
     * Clears the list of name surfer entries stored inside this class.
     */
    public void clear() {
        removeAll();

        allGraphElements.clear();
        popularityDataHashMap.clear();
        names.clear();
    }


    /* Method: addEntry(entry) */

    /**
     * Adds a new NameSurferEntry to the list of entries on the display.
     * Note that this method does not actually draw the graph, but
     * simply stores the entry; the graph is drawn by calling update.
     */
    public void addEntry(NameSurferEntry entry) {
        ArrayList<Integer> allPopularity = new ArrayList<>();
        for (int i = 0; i < NDECADES; i++) {
            allPopularity.add(entry.getRank(i));
        }

        popularityDataHashMap.put(entry.getName(), allPopularity);
        names.add(entry.getName());
    }


    /**
     * Updates the display image by deleting all the graphical objects
     * from the canvas and then reassembling the display according to
     * the list of entries. Your application must call update after
     * calling either clear or addEntry; update is also called whenever
     * the size of the canvas changes.
     */
    public void update() {
        removeAll();
        allGraphElements.clear();

        /**
         * Creates net
         */
        JLabel decadeLabel = null;
        GLine line;

        double decadeXOffset = getWidth() / NDECADES;
        double x1 = 0, x2 = 0, y1 = 0, y2 = getHeight();

        // Paints all lines and decades
        for (int i = 0; i < NDECADES; i++) {
            line = new GLine(x1, y1, x1, y2);

            decadeLabel = new JLabel(String.valueOf(START_DECADE + i * 10));
            decadeLabel.setLocation((int) (i * decadeXOffset), getHeight() - GRAPH_MARGIN_SIZE);

            add(line);
            add(decadeLabel);

            x1 += decadeXOffset;

            allGraphElements.add(line);
            allGraphElements.add(decadeLabel);
        }

        line = new GLine(0, GRAPH_MARGIN_SIZE, getWidth(), GRAPH_MARGIN_SIZE);
        add(line);
        allGraphElements.add(line);

        line = new GLine(0, getHeight() - GRAPH_MARGIN_SIZE, getWidth(), getHeight() - GRAPH_MARGIN_SIZE);
        add(line);
        allGraphElements.add(line);


        /**
         * Creates graph
         */
        if (popularityDataHashMap != null) {
            int hashMapSize = popularityDataHashMap.size();
            int colorCounter = 0;

            // Goes through the HashMap
            for (int i = 0; i < hashMapSize; i++) {

                //Determine color
                for (int j = 0; j < i; j++) {
                    if (colorCounter < 4) {
                        colorCounter = 0;
                    }
                    colorCounter++;
                }

                y2 = (getHeight() - 2 * GRAPH_MARGIN_SIZE * 1.0) / MAX_RANK * (popularityDataHashMap.get(names.get(i)).get(0));
                // Goes through the popularity data
                for (int j = 0; j < NDECADES; j++) {
                    x1 = (int) ((j * decadeXOffset) == 0 ? 0: (j * decadeXOffset)-decadeXOffset);
                    x2 = (int) (j * decadeXOffset);
                    y1 = y2;
                    y2 = (getHeight() - 2 * GRAPH_MARGIN_SIZE * 1.0) / MAX_RANK * (popularityDataHashMap.get(names.get(i)).get(j));

                    line = new GLine(x1, y1, x2, y2);
                    line.setColor(graphColors[colorCounter]);
                    allGraphElements.add(line);


                    decadeLabel = new JLabel(names.get(i) + (popularityDataHashMap.get(names.get(i)).get(j)));
                    decadeLabel.setLocation((int) (x2), (int) (y2 - decadeLabel.getHeight()));
                    allGraphElements.add(decadeLabel);

                    add(line);
                    add(decadeLabel);
                }

            }
        }
    }


    /* Implementation of the ComponentListener interface */
    public void componentHidden(ComponentEvent e) {
    }

    public void componentMoved(ComponentEvent e) {
    }

    public void componentResized(ComponentEvent e) {
        update();
    }

    public void componentShown(ComponentEvent e) {
    }
}
