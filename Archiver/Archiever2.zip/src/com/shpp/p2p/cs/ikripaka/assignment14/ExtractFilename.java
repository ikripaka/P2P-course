package com.shpp.p2p.cs.ikripaka.assignment14;

import java.io.File;
import java.util.regex.Matcher;

/**
 * This class defines the file name
 */

class ExtractFilename implements ArchiveConstants {
    private String filename, file;
    private boolean isFileArchived;

    //CONSTRUCTOR
    ExtractFilename(String[] args) throws Exception {
        if (args.length != 0) {

            String[] arrayWithData = new String[2];
            if (args[0].equals("-a")) {
                isFileArchived = false;
                arrayWithData[0] = args[1];
                arrayWithData[1] = args[2];
            } else if (args[0].equals("-u")) {
                isFileArchived = true;
                arrayWithData[0] = args[1];
                arrayWithData[1] = args[2];
            }

            if (arrayWithData[0] == null || arrayWithData[1] == null) {
                arrayWithData[0] = args[0];
                if (args.length > 1) {
                    arrayWithData[1] = args[1];
                }
            }

            File checkFile = new File(arrayWithData[0]);
            if (!checkFile.exists() || checkFile.isDirectory()) {
                throw new Exception("Invalid path to the file");
            }

            file = arrayWithData[0];
            Matcher matcher = ARCHIVED_FILE_INDICATOR.matcher(arrayWithData[0]);
            String[] splittedLine;

            if (matcher.matches()) { // check first parameter for correctness archiever format
                isFileArchived = true;
                splittedLine = arrayWithData[0].split("\\.");
                filename = splittedLine[0];
                filename = splittedLine[0];

                if (splittedLine[1] != null) { // check second parameter for correctness unarchived format or filename
                    if (UNARCHIVED_FILE_INDICATOR.matcher(splittedLine[1]).matches() ||
                            VALID_FILENAME.matcher(splittedLine[1]).matches()) {
                        splittedLine = arrayWithData[1].split("\\.");
                        filename = splittedLine[0];
                    }
                }

            } else {
                matcher = FILE_INDICATOR.matcher(arrayWithData[0]);
                if (matcher.matches()) { // check first parameter for correctness file format
                    isFileArchived = false;
                    splittedLine = arrayWithData[0].split("\\.");
                    filename = splittedLine[0];

                    if (arrayWithData[1] != null) {
                        if (ARCHIVED_FILE_INDICATOR.matcher(arrayWithData[1]).matches()) {
                            splittedLine = arrayWithData[1].split("\\.");
                            filename = splittedLine[0];
                        }
                    }

                } else {
                    throw new Exception("Second parameter is incorrect");
                }

            }

        } else {
            String[] splittedLine = DEFAULT_FILE.split("\\.");
            filename = splittedLine[0];
            file = DEFAULT_FILE;
        }

        System.out.println("Input file: " + file);
        System.out.println("Output file: " + (file.split("\\.")[1].equals("par") ? (filename + ".uar") : (filename + ".par")));
    }


    String getFilename() {
        return filename;
    }

    String getFile() {
        return file;
    }

    boolean isFileArchived() {
        return isFileArchived;
    }
}
