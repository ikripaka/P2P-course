package com.shpp.p2p.cs.ikripaka.assignment14;

/**
 * This class unpacking archived file in (.uar) format
 */

import java.io.*;
import java.util.HashMap;

class Unzip implements ArchiveConstants {
    // Contains filename of file
    private ExtractFilename filename;
    private int numberOfBitsToEncryptOneCharacter;
    // Contains (key) byte cipher - (data) symbol code
    private HashMap<Byte, Integer> ciphersForSymbolInByte;
    // Contains (key) String cipher - (data) symbol code
    private HashMap<String, Integer> ciphersForSymbolInString;
    private int bytesNumber, associationTableSize;
    private double fileSizeBefore, fileSizeAfter;

    //CONSTRUCTOR
    Unzip(ExtractFilename startFilename) {
        filename = startFilename;
        ciphersForSymbolInString = new HashMap<>();
        ciphersForSymbolInByte = new HashMap<>();
    }

    /**
     * Prints information about file size
     */
    private void printTheFileSize() {
        System.out.println("File size BEFORE: " + fileSizeBefore + " bytes ");
        System.out.println("File size AFTER: " + fileSizeAfter + " bytes ");
    }

    /**
     * This function unpacks file
     *
     * @param file               - file path
     * @param filenameForNewFile - filename for unpacked file
     * @throws IOException
     */
    private void unzipFile(String file, String filenameForNewFile) throws IOException {
        FileInputStream in = new FileInputStream(file);
        BufferedInputStream reader = new BufferedInputStream(in);
        FileOutputStream out = new FileOutputStream(filenameForNewFile + ".uar");
        BufferedOutputStream writer = new BufferedOutputStream(out);

        byte[] buffer = new byte[reader.available()];
        int bytesInFile = reader.available();
        reader.read(buffer, 0, bytesInFile);
        reader.close();

        fileSizeBefore = bytesInFile;

        StringBuilder builder = new StringBuilder();
        StringBuilder oneByteCode;
        int byteCounter = 0;

        for (int i = TABLE_LENGTH + associationTableSize; i < bytesInFile; i++) {
            oneByteCode = extractByteCode(buffer[i] < 0 ? (256 - Math.abs(buffer[i])) : buffer[i]);

            while (oneByteCode.length() != 0) {
                if (builder.length() == numberOfBitsToEncryptOneCharacter) {
                    builder = new StringBuilder();
                }
                while (builder.length() < numberOfBitsToEncryptOneCharacter && oneByteCode.length() != 0) {
                    builder.append(oneByteCode.charAt(oneByteCode.length() - 1));
                    oneByteCode.deleteCharAt(oneByteCode.length() - 1);
                }
                if (builder.length() == numberOfBitsToEncryptOneCharacter) {
                    writer.write(ciphersForSymbolInString.get(builder.toString()));
                    byteCounter++;

                    if (byteCounter == bytesNumber) break;
                }
            }
        }
        reader.close();
        writer.flush();
        writer.close();

        File getFileSize = new File(filename.getFilename() + ".uar");
        fileSizeAfter = getFileSize.length();
    }

    /**
     * Determines byte code combination in string
     *
     * @param number - the number which must be translated into a binary system of the number
     * @return - byte code (in string)
     */
    private StringBuilder extractByteCode(int number) {
        StringBuilder builder = new StringBuilder();
        while (number != 0) {
            builder.append(number % 2);
            number /= 2;
        }
        while (builder.length() < BITS_IN_ONE_BYTE) {
            builder.append("0", 0, 1);
        }
        return builder;
    }

    /**
     * Fills in string cipher for symbols
     */
    private void fillInStringByteCodeCombination() {
        String byteSequence;
        for (Byte key : ciphersForSymbolInByte.keySet()) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0, number = key; i < numberOfBitsToEncryptOneCharacter; i++) {
                builder.append(number % 2);
                number /= 2;
            }
            byteSequence = builder.toString();
            ciphersForSymbolInString.put(byteSequence, ciphersForSymbolInByte.get(key));
        }
    }

    /**
     * Calculates how many symbols wo should take to encrypt one character
     */
    private void calculateNumberOfBitsToEncryptOneCharacter() {
        int numberOfPossibleCombinations = 2;
        numberOfBitsToEncryptOneCharacter = 1;
        while (ciphersForSymbolInByte.size() > numberOfPossibleCombinations) {
            numberOfBitsToEncryptOneCharacter++;
            numberOfPossibleCombinations *= 2;
        }
    }

    /**
     * Reads table
     *
     * @param file - path to the file
     *             - 4 bytes for length of association table
     *             - 8 bytes for number of bytes of input file
     * @throws IOException
     */
    private void readTable(String file) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        StringBuilder str = new StringBuilder();

        readTableSize(reader, str);
        associationTableSize = Integer.parseInt(str.toString()) * 2;

        str = readNumberOfInputBytes(reader);
        bytesNumber = Integer.parseInt(str.toString());

        readAssociationTable(reader);
        reader.close();
    }

    /**
     * Reads association table
     *
     * @param reader - input file reader
     * @throws IOException
     */
    private void readAssociationTable(FileInputStream reader) throws IOException {
        int i;
        for (i = 12; i < associationTableSize + TABLE_LENGTH; i += 2) {
            int symbolCode = reader.read();
            int symbolCipher = reader.read();
            ciphersForSymbolInByte.put((byte) symbolCipher, symbolCode);
        }
    }

    /**
     * Reads number of input bytes
     *
     * @param reader - input file reader
     * @return - string with number of input bytes
     * @throws IOException
     */
    private StringBuilder readNumberOfInputBytes(FileInputStream reader) throws IOException {
        StringBuilder str;
        int i;
        str = new StringBuilder();
        for (i = 0; i < BITS_IN_ONE_BYTE; i++) {
            String oneByte = String.valueOf(reader.read());
            if (!oneByte.equals("0")) {
                str.append(oneByte);
            }
        }
        return str;
    }

    /**
     * Reads table size
     *
     * @param reader - input file reader
     * @param str    - String Builder which fills with table size
     * @throws IOException
     */
    private void readTableSize(FileInputStream reader, StringBuilder str) throws IOException {
        int i;
        for (i = 0; i < 4; i++) {
            String oneByte = String.valueOf(reader.read());
            if (!oneByte.equals("0")) {
                str.append(oneByte);
            }
        }
    }

    /**
     * Main method that unzip file
     *
     * @throws IOException
     */
    void unzip() throws IOException {
        readTable(filename.getFile());
        calculateNumberOfBitsToEncryptOneCharacter();
        fillInStringByteCodeCombination();
        unzipFile(filename.getFile(), filename.getFilename());

        printTheFileSize();
    }

}
