package com.shpp.p2p.cs.ikripaka.assignment14;

/**
 * The main class
 *
 * This program can:
 * - archive file in format (.par)
 * - unpack file from (.par) to (.uar)
 *
 * Class consist of main function that:
 * - controls program
 * - catches exceptions
 *
 */

public class Archiver implements ArchiveConstants {


    public static void main(String[] args) {
        try {
            ExtractFilename filename = new ExtractFilename(args);
            double startTime = System.currentTimeMillis();
            if (!filename.isFileArchived() || args[0].equals("-a")) {
                Archive archiveFile = new Archive(filename);
                archiveFile.archive();
                double timeSpent = (System.currentTimeMillis() - startTime) / 1000;
                System.out.println("Time: " + timeSpent + "sec.");
            } else {
                Unzip unzipFile = new Unzip(filename);
                unzipFile.unzip();
                double timeSpent = (System.currentTimeMillis() - startTime) / 1000;
                System.out.println("Time: " + timeSpent + "sec.");
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
