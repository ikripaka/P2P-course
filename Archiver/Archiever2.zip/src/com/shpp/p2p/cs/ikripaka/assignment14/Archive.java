package com.shpp.p2p.cs.ikripaka.assignment14;

import java.io.*;
import java.util.HashMap;

/**
 * This class can archive file into (.par) format
 * It works with String byte sequences
 */
class Archive implements ArchiveConstants {
    // Contains filename of file
    private ExtractFilename filename;
    private int numberOfBitsToEncryptOneCharacter;
    // Contains (key) byte cipher - (data) symbol code
    private HashMap<Byte, Integer> cipherForSymbolsInBytes;
    // Contains (key) symbol code - (data)  String cipher
    private HashMap<Byte, String> cipherForSymbolsInString;
    private int fileSizeBefore, fileSizeAfter;

    // CONSTRUCTOR
    Archive(ExtractFilename startFilename) {
        filename = startFilename;
        cipherForSymbolsInBytes = new HashMap<>();
        cipherForSymbolsInString = new HashMap<>();
    }


    /**
     * Calculates how many symbols wo should take to encrypt one character
     */
    private void calculateNumberOfBitsToEncryptOneCharacter() {
        int numberOfPossibleCombinations = 2;
        numberOfBitsToEncryptOneCharacter = 1;
        while (cipherForSymbolsInBytes.size() > numberOfPossibleCombinations) {
            numberOfBitsToEncryptOneCharacter++;
            numberOfPossibleCombinations *= 2;
        }
    }

    /**
     * Finds all symbols which are in the file
     *
     * @param file - string path to the file
     * @throws IOException
     */
    private void findAllSymbols(String file) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        while (true) {
            byte oneSymbol = (byte) reader.read();
            if (oneSymbol == -1) {
                break;
            }
            cipherForSymbolsInBytes.putIfAbsent(oneSymbol, 0);
        }
        reader.close();
    }

    /**
     * Fills in ByteCode combination (in string) for all letters that encrypt them
     */
    private void fillInStringByteCodeCombination() {
        String byteSequence;
        for (Byte key : cipherForSymbolsInBytes.keySet()) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0, number = cipherForSymbolsInBytes.get(key); i < numberOfBitsToEncryptOneCharacter; i++) {
                builder.append(number % 2);
                number /= 2;
            }
            byteSequence = builder.reverse().toString();
            cipherForSymbolsInString.put(key, byteSequence);
        }
    }

    /**
     * Fills in byte cipher for all symbols
     */
    private void fillInCipherForSymbols() {
        int i = 0;
        for (Byte key : cipherForSymbolsInBytes.keySet()) {
            cipherForSymbolsInBytes.put(key, i);
            i++;
        }
    }

    /**
     * Archives file
     *
     * @param file               - path to the file
     * @param filenameForNewFile - filename for archived file
     * @throws IOException
     */
    private void archiveFile(String file, String filenameForNewFile) throws IOException {
        FileInputStream in = new FileInputStream(file);
        BufferedInputStream reader = new BufferedInputStream(in);
        FileOutputStream out = new FileOutputStream(filenameForNewFile + ".par");
        BufferedOutputStream writer = new BufferedOutputStream(out);


        int fileSize = (reader.available());
        fileSizeBefore = fileSize;
        byte[] table = formTable(fileSize);
        writer.write(table);

        byte[] buffer = new byte[fileSize];
        reader.read(buffer, 0, buffer.length);
        reader.close();

        int filledBitsInBytes = 0;
        StringBuilder byteSequence;
        StringBuilder builder = new StringBuilder();
        String remainder = null;

        for (int i = 0; i < fileSize; i++) {
            byte oneSymbolCode = buffer[i];
            byteSequence = new StringBuilder(remainder == null ? cipherForSymbolsInString.get(oneSymbolCode) :
                    cipherForSymbolsInString.get(oneSymbolCode) + remainder);
            remainder = null;
            while (!(byteSequence.length() == 0)) {
                if (filledBitsInBytes < BITS_IN_ONE_BYTE) {
                    builder.append(byteSequence.charAt(byteSequence.length() - 1));
                    byteSequence = byteSequence.deleteCharAt(byteSequence.length() - 1);
                    filledBitsInBytes++;

                    if (filledBitsInBytes == BITS_IN_ONE_BYTE) {
                        filledBitsInBytes = 0;
                        String str = builder.toString();
                        byte lineInByte = (byte) Integer.parseInt(str, 2);
                        writer.write(lineInByte);
                        remainder = null;
                        builder = new StringBuilder();

                        if (!(byteSequence.length() == 0)) {
                            remainder = byteSequence.toString();
                            filledBitsInBytes = 0;
                            break;
                        }
                    }
                }
            }
        }

        if (remainder != null) {
            builder = new StringBuilder(remainder);
            while (builder.length() < BITS_IN_ONE_BYTE) {
                builder.append("0");
            }
            byte a = Byte.parseByte(remainder, 2);
            writer.write(a);
            filledBitsInBytes = 0;
        }

        if (filledBitsInBytes < BITS_IN_ONE_BYTE && filledBitsInBytes != 0) {
            while (builder.length() < BITS_IN_ONE_BYTE) {
                builder.append("0");
            }

            String str = builder.toString();
            byte lineInByte = Byte.parseByte(str, 2);
            writer.write(lineInByte);
        }

        reader.close();
        writer.flush();
        writer.close();

        File getFileSize = new File(filename.getFilename() + ".par");
        fileSizeAfter = (int) getFileSize.length();
    }

    /**
     * Forms table that consist of
     * - 4 bytes for length of association table
     * - 8 bytes for number of bytes of input file
     *
     * @param fileLength - file size
     * @return buffer -
     */
    private byte[] formTable(int fileLength) {
        byte[] buffer = new byte[TABLE_LENGTH + cipherForSymbolsInBytes.size() * 2];

        int i = TABLE_LENGTH;
        int number = fileLength;
        i = writeNumberOfInputBytes(buffer, i, number);
        writeTableSize(buffer, i);

        writeAssociationTable(buffer);

        return buffer;
    }

    /**
     * Writes number of input bytes in the table
     *
     * @param buffer - table
     * @param i      - counter
     * @param number - number that we should write in the table
     * @return - i(counter)
     */
    private int writeNumberOfInputBytes(byte[] buffer, int i, int number) {
        for (int counter = 0; counter < BITS_IN_ONE_BYTE; counter++) {
            buffer[i - 1] = (byte) (number % 100);
            number /= 100;
            i--;
        }
        return i;
    }

    /**
     * Writes association table size
     *
     * @param buffer - table
     * @param i      - counter
     */
    private void writeTableSize(byte[] buffer, int i) {
        int number;
        number = cipherForSymbolsInBytes.size();
        for (int counter = 0; counter < 4; counter++) {
            buffer[i - 1] = (byte) (number % 100);
            number /= 100;
            i--;
        }
    }

    /**
     * Writes association table
     *
     * @param buffer - table
     */
    private void writeAssociationTable(byte[] buffer) {
        int i = TABLE_LENGTH;
        for (Byte key : cipherForSymbolsInBytes.keySet()) {
            buffer[i] = key;
            buffer[i + 1] = cipherForSymbolsInBytes.get(key).byteValue();
            i += 2;
        }
    }

    /**
     * Prints file size
     */
    private void printTheFileSize() {
        System.out.println("File size BEFORE: " + fileSizeBefore + " bytes ");
        System.out.println("File size AFTER: " + fileSizeAfter + " bytes ");
        System.out.println("Compression: " + ((fileSizeAfter / fileSizeBefore) * 100) + " %");
    }

    /**
     * Main method that makes archiving
     *
     * @throws IOException
     */
    void archive() throws IOException {
        findAllSymbols(filename.getFile());
        fillInCipherForSymbols();
        calculateNumberOfBitsToEncryptOneCharacter();

        fillInStringByteCodeCombination();

        archiveFile(filename.getFile(), filename.getFilename());

        printTheFileSize();
    }
}
