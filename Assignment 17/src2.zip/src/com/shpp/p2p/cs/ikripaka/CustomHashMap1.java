package com.shpp.p2p.cs.ikripaka;

import com.shpp.p2p.cs.ikripaka.assignment16.CustomArrayList;

/**
 * Class based on hash tables, stores data in the form of key/value pairs.
 * Keys and values can be of any type, including null.
 * This implementation does not guarantee the order of the elements over time.
 * Collision resolution is performed using the chaining method.
 * The most methods are borrowed from the class java.util.HashMap, reworked, simplified and decomposed.
 *
 * @param <K> is a generic type of a key
 * @param <V> is a generic type of a value
 */
public class CustomHashMap1<K, V> {
    /**
     * The number of key-value buckets contained in this map
     */
    private int size;
    /**
     * The capacity of array of this map
     */
    private int capacity;
    /**
     * The table, initialized on first use, and resized as necessary.
     * When allocated, length is always a power of two.
     */
    private Entry<K, V>[] table;
    /**
     * The default initial capacity - MUST be a power of two.
     */
    private static final int DEFAULT_CAPACITY = 16;

    /**
     * The basic class in which the buckets of key-value pairs,
     * the hash and the reference to the next element are stored,
     * which is needed in case of collisions,
     * when a singly-linked list is constructed from a cell in the main array
     */
    public static class Entry<K, V> {
        K key;
        V value;
        int hash;
        Entry<K, V> next;

        Entry(int hash, K key, V value, Entry<K, V> next) {
            this.key = key;
            this.value = value;
            this.hash = hash;
            this.next = next;
        }

        public String toString() {
            return key + "=" + value;
        }

        public K getKey() {
            return this.key;
        }

        public V getValue() {
            return this.value;
        }
    }


    /**
     * Constructs an empty HashMap with the default initial capacity (16)
     */
    @SuppressWarnings("unchecked")
    public CustomHashMap1() {
        this.size = 0;
        this.capacity = DEFAULT_CAPACITY;
        table = new Entry[capacity];
    }

    /**
     * Computes key.hashCode() and spreads (XORs) higher bits of getHash to lower.
     */
    private int getHash(Object key) {
        if (key != null) {
            int h = key.hashCode();
            return key.hashCode() ^ h >> 16;
        } else {
            return 0;
        }
    }

    /**
     * Finds the index by hash in the array for the key-value pair and creates a new entry.
     * If this cell is not empty, it starts to build a single-linked list.
     * Each time it checks the index and size and doubles the size when the size reaches its capacity.
     * When increasing the size - all indexes are re-calculated based on the hashes and redefined to new cells.
     * If exactly the same key arrives, replaces its value with a new value, and returns the old
     *
     * @param key   is the key with which the specified value is to be associated
     * @param value value to be associated with the specified key
     * @return the previous value associated with key, or null if there was no mapping for key.
     */
    public V put(K key, V value) {
        V oldValue;
        int hash = getHash(key);
        int index = hash & capacity - 1;
        resize();
        if (table[index] == null) {
            table[index] = new Entry<>(hash, key, value, null);
            size++;
        } else if (key.equals(table[index].key)) {
            oldValue = table[index].value;
            table[index].value = value;
            return oldValue;
        } else if (table[index].key != key) {
            return buildTheChain(key, value, hash, index);
        }
        return null;
    }

    /**
     * Builds a unidirectional linked list in case of collisions.
     * Checks if there is already such a key in the chain,
     * if exists - replaces, if not, adds a new entry at the end of the chain
     *
     * @param key   is the key with which the specified value is to be associated
     * @param value is the value to be associated with the specified key
     * @param hash  is a calculated hash
     * @param index is a calculated index
     * @return the previous value associated with key, or null if there was no mapping for key.
     */
    private V buildTheChain(K key, V value, int hash, int index) {
        V oldValue;
        Entry<K, V> listEntry = table[index].next;
        if (listEntry != null) {
            if (key.equals(listEntry.key)) {
                oldValue = listEntry.value;
                listEntry.value = value;
                return oldValue;
            } else {
                while (listEntry.next != null) {
                    listEntry = listEntry.next;
                    if (key.equals(listEntry.key)) {
                        oldValue = listEntry.value;
                        listEntry.value = value;
                        return oldValue;
                    }
                }
            }
            listEntry.next = new Entry<>(hash, key, value, null);
            size++;
        } else {
            table[index].next = new Entry<>(hash, key, value, null);
            size++;
        }
        return null;
    }

    /**
     * Checks if we need to increase the capacity of our array
     */
    private void resize() {
        if (size + 1 == capacity) {
            capacity *= 2;
            relocate();
        }
    }


    /**
     * Enumerates all elements of the current storage,
     * recalculates their indexes (taking into account the new capacity)
     * and redistributes the elements over the new array.
     **/
    @SuppressWarnings("unchecked")
    private void relocate() { //очень сложна
        Entry<K, V>[] temp = new Entry[capacity];
        int hash, index;
        Entry<K, V> oldListE, newListE;
        for (Entry<K, V> arrayEntry : table) {
            if (arrayEntry != null) {
                oldListE = arrayEntry;
                while (oldListE != null) {
                    hash = oldListE.hash;
                    index = hash & capacity - 1;
                    if (temp[index] == null) {
                        temp[index] = new Entry<>(hash, oldListE.key, oldListE.value, null);
                    } else if (temp[index].key.equals(oldListE.key)) {
                        temp[index].value = oldListE.value;
                    } else if (!temp[index].key.equals(oldListE.key)) {
                        newListE = temp[index].next;
                        if (newListE == null) {
                            temp[index].next = new Entry<>(hash, oldListE.key, oldListE.value, null);
                        } else {
                            while (newListE.next != null) {
                                newListE = newListE.next;
                            }
                            newListE.next = new Entry<>(hash, oldListE.key, oldListE.value, null);
                        }
                    }
                    oldListE = oldListE.next;
                }
            }
        }
        table = temp;
    }


    /**
     * Searches for an entry by a given key:
     * calculates the hash,
     * calculates the index by hash,
     * checks the cell in the array,
     * checks the linked list to this cell.
     *
     * @param key is the key whose associated value is to be returned
     * @return the value to which the specified key is mapped, or null if this map contains no mapping for the key
     */
    public V get(Object key) { //сложна
        int hash = getHash(key);
        int index = hash & capacity - 1;
        if (table[index] == null) {
            return null;
        } else if (key.equals(table[index].key)) {
            return table[index].value;
        } else if (!key.equals(table[index].key)) {
            Entry<K, V> listEntry;
            listEntry = table[index].next;
            if (listEntry == null) {
                return null;
            } else {
                if (key.equals(listEntry.key)) {
                    return listEntry.value;
                } else {
                    while (listEntry.next != null) {
                        listEntry = listEntry.next;
                        if (key.equals(listEntry.key)) {
                            return listEntry.value;
                        }
                    }
                }
            }
        }
        return null;
    }


    /**
     * Searches for an entry by a given key:
     * calculates the hash,
     * calculates the index by hash,
     * checks the cell in the array,
     * checks the linked list to this cell.
     *
     * @param key is the key whose presence in this map is to be tested
     * @return true if this map contains a mapping for the specified key.
     */
    public boolean containsKey(Object key) { //сложна
        int hash = getHash(key);
        int index = hash & capacity - 1;
        if (table[index] == null) {
            return false;
        } else if (key.equals(table[index].key)) {
            return true;
        } else if (!key.equals(table[index].key)) {
            Entry<K, V> listEntry;
            listEntry = table[index].next;
            if (listEntry == null) {
                return false;
            } else {
                if (key.equals(listEntry.key)) {
                    return true;
                } else {
                    while (listEntry.next != null) {
                        listEntry = listEntry.next;
                        if (key.equals(listEntry.key)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Checks every cell in the array, and then,
     * every node in the list growing out of that cell
     *
     * @param value is the value whose presence in this map is to be tested
     * @return true if this map maps one or more keys to the specified value
     */
    boolean containsValue(Object value) {
        Entry<K, V> current;
        for (Entry<K, V> bucket : table) {
            for (current = bucket; current != null; current = current.next) {
                if (value == null) {
                    if (current.value == null)
                        return true;
                } else {
                    if (value.equals(current.value))
                        return true;
                }
            }
        }
        return false;
    }


    /**
     * Removes the mapping for the specified key from this map if present.
     *
     * @param key is the key whose mapping is to be removed from the map
     * @return the previous value associated with key, or null if there was no mapping for key.
     * (A null return can also indicate that the map previously associated null with key.)
     */
    public V remove(Object key) { //сложна
        V oldValue;
        int hash = getHash(key);
        int index = hash & capacity - 1;
        if (table[index] == null) {
            return null;
        } else if (key.equals(table[index].key)) {
            oldValue = table[index].value;
            if (table[index].next == null) {
                table[index] = null;
            } else {
                table[index] = table[index].next;
            }
            size--;
            return oldValue;
        } else if (!key.equals(table[index].key)) {
            Entry<K, V> prev = table[index];
            Entry<K, V> current = table[index].next;
            while (current != null) {
                if (key.equals(current.key)) {
                    oldValue = current.value;
                    if (current.next != null) {
                        prev.next = current.next;
                    } else {
                        prev.next = null;
                    }
                    size--;
                    return oldValue;
                }
                current = current.next;
                prev = prev.next;
            }
        }
        return null;
    }

    /**
     * Removes all of the mappings from this map.
     * Just re-initializes the basic array
     */
    @SuppressWarnings("unchecked")
    public void clear() {
        this.size = 0;
        this.capacity = DEFAULT_CAPACITY;
        table = new Entry[capacity];
    }

    /**
     * @return the number of key-value mappings in this map
     */
    public int size() {
        return this.size;
    }

    /**
     * @return true if this map contains no key-value mappings
     */
    public boolean isEmpty() {
        return this.size == 0;
    }

    /**
     * Returns a string representation of this map.  The string representation
     * consists of a list of key-value mappings in the order returned by the
     * map's {entrySet} view's iterator, enclosed in braces
     * ({"{}"}).  Adjacent mappings are separated by the characters
     * {", "} (comma and space).  Each key-value mapping is rendered as
     * the key followed by an equals sign ({"="}) followed by the
     * associated value.  Keys and values are converted to strings.
     *
     * @return a string representation of this map
     */
    @Override
    public String toString() {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("{");
        for (Entry<K, V> entry : this.entrySet())
            strBuilder.append(entry).append(", ");
        if (strBuilder.length() > 1)
            strBuilder.delete(strBuilder.length() - 2, strBuilder.length());
        strBuilder.append('}');
        return String.valueOf(strBuilder);
    }

    /**
     * @return an ArrayList for iteration
     */
    public CustomArrayList<Entry<K, V>> entrySet() {
        Entry<K, V> current;
        CustomArrayList<Entry<K, V>> entrySet = new CustomArrayList<>();
        for (Entry<K, V> bucket : table)
            for (current = bucket; current != null; current = current.next)
                entrySet.add(current);
        return entrySet;
    }
    //todo где итератор?
}
