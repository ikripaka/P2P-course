package com.shpp.p2p.cs.ikripaka.assignment10;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class consists of the constants which is using in the classes
 */

class Constants {
    Pattern NUMBER = Pattern.compile("[\\d|.]+");
    Pattern LETTERS = Pattern.compile("[\\w]+");

    Pattern ALL_ARITHMETICAL_OPERATIONS = Pattern.compile("[/^*+-]");

    /**
     * Checks if the symbol - operator
     *
     * @param symbols - one symbol in String
     * @return - true/false  if symbol matches
     */
    boolean matches(String symbols, Pattern pattern) {
        Matcher match = pattern.matcher(String.valueOf(symbols));
        return match.matches();
    }
}
