package com.shpp.p2p.cs.ikripaka.assignment10Part1;

import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Matcher;

/**
 * -------- CALCULATOR --------
 * This class calculates expressions
 * which can contain these symbols:
 * ^, *, /, +, -, (, )
 * and these functions:
 * sin, cos, tan, atan, sqrt, log10
 * It bases on the ReversePolishNotation
 */

public class Calculator implements ArithmeticalOperationsConstants {
    public static void main(String[] args) {
        try {
            System.out.println("Input " + args[0]);

            isThisLineCorrect(args[0]);

            HashMap<String, Double> variables = fillInVariablesInHashMap(args);

            ParseInputData divideLine = new ParseInputData(args[0]);
            String RPNNote = divideLine.getParsedLine();
            //System.out.println(RPNNote);

            CalculateEquation calculate = new CalculateEquation(RPNNote, variables);
            System.out.println("Result " + calculate.getResult());

        } catch (Exception e) {
            System.err.println("Incorrect expression");
            System.out.println(e.getMessage());
            System.out.println(Arrays.toString(e.getStackTrace()));
        }

    }

    private static void isThisLineCorrect(String arg) throws Exception {
        if (arg == null) throw new Exception("The line is empty");
        int openBracket = 0, closeBracket = 0;
        for(int i =0; i < arg.length(); i++){
            if(arg.toCharArray()[i] == '(') openBracket++;
            if(arg.toCharArray()[i] == ')') closeBracket++;
        }
        if(openBracket != closeBracket) throw new Exception("Wrong parentheses");
    }

    /**
     * Fills HashMap with arrays and numeric numbers
     *
     * @param args      - input String array
     */
    private static HashMap<String, Double> fillInVariablesInHashMap(String[] args) throws Exception {
        HashMap<String, Double> variables = new HashMap<>();
        Matcher match;
        if (args.length > 1) {
            for (int i = 1; i < args.length; i++) {
                String letter[] = args[i].split("=");
                match = LETTERS.matcher(letter[0]);
                if (!match.matches()) {
                    throw new Exception("Incorrect VARIABLES");
                }
                variables.put(letter[0], Double.valueOf(letter[1]));
            }
        }
        return variables;
    }


}