package com.shpp.p2p.cs.ikripaka.assignment10Part1;

import java.util.Arrays;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Divides line with equation to note in RPN
 */
class ParseInputData implements ArithmeticalOperationsConstants {
    private StringBuilder parsedLine = new StringBuilder();
    private char[] lineWithEquation;

    // Constructor
    ParseInputData(String startLine) {
        lineWithEquation = startLine.toCharArray();
        divideLine();
    }

    /**
     * Gets parsed line
     *
     * @return - parsed line
     */
    String getParsedLine() {
        return parsedLine.toString();
    }

    /**
     * Divides line into RPN
     */
    private void divideLine() {
        Stack<String> stack = new Stack<>();
        int length = lineWithEquation.length;

        // Runs over all symbols
        for (int i = 0; i < length; i++) {

            // if symbol - number
            if (matches(String.valueOf(lineWithEquation[i]), NUMBER)) {
                parsedLine.append(lineWithEquation[i]);
                continue;
            }

            // if symbol - letter
            if (matches(String.valueOf(lineWithEquation[i]), LETTERS)) {
                switch (lineWithEquation[i]) {

                    //if function (sin)
                    case 's':

                        switch (lineWithEquation[i + 1]) {
                            case 'i':
                                if (lineWithEquation.length - i > "sin".length()) {
                                    if (isSin(lineWithEquation[i + 1], lineWithEquation[i + 2])) {
                                        i += "sin".length() - 1;
                                        stack.push("sin");
                                    } else {
                                        parsedLine.append(lineWithEquation[i]);
                                    }
                                } else {
                                    parsedLine.append(lineWithEquation[i]);
                                }
                                continue;

                            case 'q':
                                if (lineWithEquation.length - i > "sqrt".length()) {
                                    if (lineWithEquation[i + 1] == 'q') {
                                        if (isSqrt(lineWithEquation[i + 2], lineWithEquation[i + 3])) {
                                            i += "sqrt".length() - 1;
                                            stack.push("sqrt");
                                        } else {
                                            parsedLine.append(lineWithEquation[i]);
                                        }
                                    } else {
                                        parsedLine.append(lineWithEquation[i]);
                                    }
                                }
                                continue;
                        }

                        //if function (sin)
                    case 'c':
                        if (lineWithEquation.length - i > "cos".length()) {
                            if (isCos(lineWithEquation[i + 1], lineWithEquation[i + 2])) {
                                i += "cos".length() - 1;
                                stack.push("cos");
                            } else {
                                parsedLine.append(lineWithEquation[i]);
                            }
                        } else {
                            parsedLine.append(lineWithEquation[i]);
                        }
                        continue;
                        //if function (tan)
                    case 't':
                        if (lineWithEquation.length - i > "tan".length()) {
                            if (isTan(lineWithEquation[i + 1], lineWithEquation[i + 2])) {
                                i += "tan".length() - 1;
                                stack.push("tan");
                            } else {
                                parsedLine.append(lineWithEquation[i]);
                            }
                        } else {
                            parsedLine.append(lineWithEquation[i]);
                        }
                        continue;
                        //if function (atan)
                    case 'a':
                        if (lineWithEquation.length - i > "atan".length()) {
                            if (lineWithEquation[i + 1] == 't') {
                                if (isTan(lineWithEquation[i + 2], lineWithEquation[i + 3])) {
                                    i += "atan".length() - 1;
                                    stack.push("atan");
                                } else {
                                    parsedLine.append(lineWithEquation[i]);
                                }
                            } else {
                                parsedLine.append(lineWithEquation[i]);
                            }
                        }
                        continue;
                        //if function (log10)
                    case 'l':
                        if (lineWithEquation.length - i > "log10".length()) {
                            if (isLog(lineWithEquation[i + 1], lineWithEquation[i + 2])) {
                                if (lineWithEquation[i + 3] == '1') {
                                    if (lineWithEquation[i + 4] == '0') {
                                        i += "log10".length() - 1;
                                        stack.push("log10");
                                    } else {
                                        parsedLine.append(lineWithEquation[i]);
                                    }
                                } else {
                                    parsedLine.append(lineWithEquation[i]);
                                }
                            } else {
                                parsedLine.append(lineWithEquation[i]);
                            }
                        } else {
                            parsedLine.append(lineWithEquation[i]);
                        }
                        continue;
                }
                continue;
            }

            // if (minus(-) before brackets)
            if (lineWithEquation[i] == '-' && lineWithEquation[i + 1] == '(') {
                stack.push("-");
                parsedLine.append(0);
                parsedLine.append(" ");
                continue;
            }

            // if (1 symbol == '(')
            if (lineWithEquation[i] == '(') {
                stack.push("(");
                continue;
            }

            // if (1 symbol == ')')
            if (!stack.empty() && lineWithEquation[i] == ')') {
                while (!stack.empty() && !stack.peek().equals("(")) {
                    parsedLine.append(' ');
                    parsedLine.append(stack.peek());
                    stack.remove(stack.peek());
                }
                stack.remove(stack.peek());
                continue;
            }

            // if symbol - arithmetical operation
            if (matches(String.valueOf(lineWithEquation[i]), ALL_ARITHMETICAL_OPERATIONS)) {

                // if user print negative number
                if ((i > 1 && lineWithEquation[i] == '-' && matches(String.valueOf(lineWithEquation[i - 1]), ALL_ARITHMETICAL_OPERATIONS))
                        || (i == 0 && lineWithEquation[i] == '-' && matches(String.valueOf(lineWithEquation[i + 1]), NUMBER))
                        || (i == 0 && lineWithEquation[i] == '-' && matches(String.valueOf(lineWithEquation[i + 1]), LETTERS))
                        || (i > 0 && lineWithEquation[i] == '-' && matches(String.valueOf(lineWithEquation[i - 1]), FOURTH_PRIORITY))) {
                    parsedLine.append('-');
                    continue;
                }


                parsedLine.append(' ');

                //if (operation in stack = ^) and (current operation in line = ^)
                if (stack.size() >= 1 && matches(stack.peek(), FIRST_PRIORITY)
                        && matches(String.valueOf(lineWithEquation[i]), FIRST_PRIORITY)) {
                    stack.push(String.valueOf(lineWithEquation[i]));
                    continue;
                }

                // if (operation from stack prioritise >= prioritise of current symbol from line)
                if (stack.size() >= 1 && (functions.contains(stack.peek()) || stack.size() >= 1 && prioritize(stack.peek()) >= prioritize(String.valueOf(lineWithEquation[i])))) {

                    parsedLine.append(stack.peek());
                    stack.remove(stack.peek());
                    parsedLine.append(' ');

                    // Forces out all symbols if (operation from stack priority > current operation in line)
                    while (stack.size() >= 1 && prioritize(stack.peek()) >= prioritize(String.valueOf(lineWithEquation[i]))) {
                        parsedLine.append(stack.peek());
                        parsedLine.append(' ');
                        stack.remove(stack.peek());
                    }

                    stack.push(String.valueOf(lineWithEquation[i]));
                } else {
                    stack.push(String.valueOf(lineWithEquation[i]));
                }
            }

        }

        // Forced out all remaining operations
        int size = stack.size();
        for (int i = 0; i < size; i++) {
            parsedLine.append(' ');
            parsedLine.append(stack.peek());
            stack.remove(stack.peek());
        }

    }

    /**
     * Compares symbol with Patterns
     *
     * @param symbol  - char symbol
     * @param pattern - pattern which we must use
     * @return - true/false if symbol matches
     */
    private boolean matches(String symbol, Pattern pattern) {
        Matcher match = pattern.matcher(String.valueOf(symbol));
        return match.matches();
    }

    /**
     * Determine what prioritise in arithmetical operation
     *
     * @param operation - arithmetical operation
     * @return - number of operation priority
     */
    private int prioritize(String operation) {
        Matcher match = FIRST_PRIORITY.matcher(operation);
        if (match.matches()) {
            return 3;
        }

        match = SECOND_PRIORITY.matcher(operation);
        if (match.matches()) {
            return 2;
        }

        match = THIRD_PRIORITY.matcher(operation);
        if (match.matches()) {
            return 1;
        }
        return 0;
    }

    /**
     * Is letters - sin function
     *
     * @param var1 - second letter of function
     * @param var2 - third letter of function
     * @return - boolean (true/false)
     */
    private boolean isSin(char var1, char var2) {

        if (var1 == 'i') {
            return var2 == 'n';
        }
        return false;
    }

    /**
     * Is letters - SIN function
     *
     * @param var1 - second letter of function
     * @param var2 - third letter of function
     * @return - boolean (true/false)
     */
    private boolean isCos(char var1, char var2) {
        if (var1 == 'o') {
            return var2 == 's';
        }
        return false;
    }

    /**
     * Is letters - COS function
     *
     * @param var1 - second letter of function
     * @param var2 - third letter of function
     * @return - boolean (true/false)
     */
    private boolean isTan(char var1, char var2) {
        if (var1 == 'a') {
            return var2 == 'n';
        }
        return false;
    }

    /**
     * Is letters - SQRT function
     *
     * @param var1 - third letter of function
     * @param var2 - fourth letter of function
     * @return - boolean (true/false)
     */
    private boolean isSqrt(char var1, char var2) {
        if (var1 == 'r') {
            return var2 == 't';
        }
        return false;
    }

    /**
     * Is letters - LOG function
     *
     * @param var1 - second letter of function
     * @param var2 - third letter of function
     * @return - boolean (true/false)
     */
    private boolean isLog(char var1, char var2) {
        if (var1 == 'o') {
            return var2 == 'g';
        }
        return false;
    }
}
