package com.shpp.p2p.cs.ikripaka.assignment10Part1;

/**
 * Calculates expression
 * It bases on RPN
 */

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class CalculateEquation implements ArithmeticalOperationsConstants {
    private double result = 0;
    private LinkedList<String> dividedLine;
    private HashMap<String, Double> allVariables;

    //Constructor
    CalculateEquation(String RPNnote, HashMap<String, Double> variables) {
        allVariables = variables;
        dividedLine = replaceArraysWithNumbers(fillLinkedListWithString(RPNnote.split(" ")));
        allVariables = variables;
        calculate();
    }

    private LinkedList<String> replaceArraysWithNumbers(LinkedList<String> list) {
        for (int i = 0; i < list.size(); i++) {
            if ((!functions.contains(list.get(i))) && matches(list.get(i), LETTERS)) {
                list.set(i, allVariables.get(list.get(i)).toString());
            }
        }
        return list;
    }


    private void calculate() {
        double intermediateResult = 0;

        // Calculate
        for (int i = 0; i < dividedLine.size(); i++) {
            try {
                // Do arithmetical operation
                if (matches(dividedLine.get(i), ALL_ARITHMETICAL_OPERATIONS)) {
                    switch (dividedLine.get(i)){
                        case "^":
                            intermediateResult = raiseToAPower(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                        case "*":
                            intermediateResult = multiply(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                        case "/":
                            intermediateResult = divide(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                        case "+":
                            intermediateResult = plus(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                        case "-":
                            intermediateResult = minus(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                    }
                    dividedLine.remove(i);
                    dividedLine.remove(i - 1);
                    dividedLine.set(i - 2, String.valueOf(intermediateResult));
                    i-=2;
                }
                // Do functions
                if(functions.contains(dividedLine.get(i))){
                    switch (dividedLine.get(i)){
                        case "sin":
                            intermediateResult = Math.sin(Math.toRadians(Double.parseDouble(dividedLine.get(i-1))));
                        case "cos":
                            intermediateResult = Math.cos(Math.toRadians(Double.parseDouble(dividedLine.get(i-1))));
                        case "tan":
                            intermediateResult = Math.tan(Math.toRadians(Double.parseDouble(dividedLine.get(i-1))));
                        case "atan":
                            intermediateResult = Math.atan(Double.parseDouble(dividedLine.get(i-1)));
                        case "sqrt":
                            intermediateResult = Math.sqrt(Double.parseDouble(dividedLine.get(i-1)));
                        case "log10":
                            intermediateResult = Math.log10(Double.parseDouble(dividedLine.get(i-1)));

                    }
                    dividedLine.remove(i);
                    dividedLine.set(i - 1, String.valueOf(intermediateResult));
                    i-=1;
                }

            } catch (Exception e) {
                System.err.println("There are some troubles with the numbers");
                e.printStackTrace();
                System.out.println(e.getMessage());
                System.exit(0);
            }
        }

        if (!dividedLine.get(0).equals("")) {
            result = Double.valueOf(dividedLine.get(0));
        } else if (dividedLine.size() > 1) {
            result = Double.valueOf(dividedLine.get(1));
        }
    }

    /**
     * Records all data to LinkedList
     *
     * @param array - splitted line
     * @return - LinkedList with divided information
     */
    private LinkedList<String> fillLinkedListWithString(String[] array) {
        LinkedList<String> list = new LinkedList<>();
        Collections.addAll(list, array);
        return list;
    }

    /**
     * Checks if the symbol - operator
     *
     * @param symbols - one symbol in String
     * @return - true/false  if symbol matches
     */
    private boolean matches(String symbols, Pattern pattern) {
        Matcher match = pattern.matcher(String.valueOf(symbols));
        return match.matches();
    }

    /**
     * Pluses two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - adding two numbers
     */
    private double plus(double var1, double var2) {
        return var1 + var2;
    }

    /**
     * Minuses two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - difference of two numbers
     */
    private double minus(double var1, double var2) {
        return var1 - var2;
    }

    /**
     * Multiply two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - product of two numbers
     */
    private double multiply(double var1, double var2) {
        return var1 * var2;
    }

    /**
     * Divides two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - share of two numbers
     */
    private double divide(double var1, double var2) {
        return var1 / var2;
    }

    /**
     * Raises to power var1 number in var2 power
     *
     * @param var1 - number
     * @param var2 - power
     * @return - raise to power
     */
    private double raiseToAPower(double var1, double var2) {
        return Math.pow(var1, var2);
    }

    double getResult() {
        return result;
    }
}
