package com.shpp.p2p.cs.ikripaka.assignment16;

/**
 * Creates Collection (CustomQueue)
 * @param <T> - Collection type
 */
public class CustomQueue<T> {
    private Node head, end;
    private int size;

    CustomQueue() {
        size = 0;
    }

    /**
     * Inserts the specified element into this queue
     * @param element - element that inserts
     */
    public void add(T element){
        if(size == 0){
            head = new Node(element, null);
            size++;
        }else if(size == 1){
            end = new Node(element, null);
            head.setLink(end);
            size++;
        }else{
            Node node = new Node(element, null);
            end.setLink(node);
            end = node;
            size++;
        }
    }

    /**
     * Retrieves, but does not remove,
     * the head of this queue,
     * or returns null if this queue is empty.
     * @return - element in peek
     */
    public T peek(){
        return (T) head.data;
    }

    /**
     * Retrieves and removes the head of this queue,
     * or returns null if this queue is empty.
     * @return
     */
    public T poll(){
        if(size > 0) {
            Object data = head.data;
            head = head.next;
            size --;
            return (T) data;
        }
        return null;
    }

    /**
     * Retrieves and removes the head of this queue.
     * @return - element that was in the node
     */
    public T remove(){
        if(size > 0){
            Object data = head.data;
            head = head.next;
            size--;
            return (T) data;
        }
        System.err.println("EmptyQueue");
        System.exit(0);
        return null;
    }

    /**
     * Tests if this queue is empty.
     * @return - (true) Queue is empty/ (false) Queue has elements
     */
    public boolean empty() {
        return size == 0;
    }

    /**
     * Node for Queue
     */
    class Node {
        private Node next;
        private Object data;

        Node(T data, Node prev) {
            this.data = data;
            next = prev;
        }
        public void setLink(Node next){ this.next = next;}
    }
}
