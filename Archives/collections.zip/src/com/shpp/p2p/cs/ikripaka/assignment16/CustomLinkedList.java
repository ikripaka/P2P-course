package com.shpp.p2p.cs.ikripaka.assignment16;

/**
 * Creates Collection(CustomLinkedList)
 * @param <T> - Collection type
 */
public class CustomLinkedList<T> {
    private Node first, last;
    private int size;

    CustomLinkedList() {
        size = 0;
    }

    /**
     * Appends the specified element to the end of this list.
     *
     * @param element - element that appends
     * @return - (true) element appends successful
     */
    public boolean add(T element) {
        if (size == 0) {
            last = new Node(null, null, null);
            first = new Node(element, last, null);
            last.setPrevLink(first);
        } else if (size == 1) {
            last.setElement(element);
        } else {
            Node node = new Node(element, null, last);
            last.setNextLink(node);
            last = node;
        }
        size++;
        return true;
    }

    /**
     * Inserts the specified element at the beginning of this list.
     *
     * @param element - element that inserts
     */
    public void addFirst(T element) {
        if (size == 0) {
            last = new Node(null, null, null);
            first = new Node(element, last, null);
            last.setPrevLink(first);
        } else if (size == 1) {
            last.setElement(first.data);
            first.setElement(element);
        } else {
            Node node = new Node(element, first, null);
            first.setPrevLink(node);
            first = node;
        }
        size++;
    }

    /**
     * Whether or not list is found
     * @return - (true) - empty/(false) - filled with element(s)
     */
    public boolean isEmpty(){return size == 0;}

    /**
     * Appends the specified element to the end of this list.
     *
     * @param element - ellement that appends ti the end
     */
    public void addLast(T element) {
        if (size == 0) {
            last = new Node(null, null, null);
            first = new Node(element, last, null);
            last.setPrevLink(first);
        } else if (size == 1) {
            last.setElement(element);
        } else {
            Node node = new Node(element, last, null);
            last.setNextLink(node);
            last = node;
        }
        size++;
    }

    /**
     * Removes all of the elements from this list.
     */
    public void clear() {
        size = 0;
        first = null;
        last = null;
    }

    /**
     * Returns true if this list contains the specified element.
     *
     * @param element
     * @return
     */
    public boolean contains(Object element) {
        Node node = first;
        for (int i = 1; i < size; i++, node = node.next) {
            if (node.data == element) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the element at the specified position in this list.
     *
     * @param index - index of element
     * @return - element data at the specified position
     */
    public T get(int index) {
        checkIndex(index);
        Node node = first;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        return (T) node.data;
    }

    /**
     * Checks index (if it correct)
     * @param index - current index
     */
    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            System.err.println("outOfBoundsCheckIndex: your index " + index +
                    " possible index from 0 ");
            System.exit(0);
        }
    }

    /**
     * Returns the first element in this list.
     *
     * @return - first element in this list
     */
    public T getFirst() {
        if (checkSize())
            return (T) first.data;

        System.out.println("outOfBoundsException");
        System.exit(0);
        return null;
    }

    /**
     * Returns the last element in this list.
     *
     * @return - last element in this list
     */
    public T getLast() {
        if (size == 1) {
            return (T) first.data;
        } else if (size > 1) {
            return (T) last.data;
        }
        System.out.println("outOfBoundsException");
        System.exit(0);
        return null;
    }

    /**
     * Returns the index of the first occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     *
     * @param object - element that function search
     * @return - index of element of -1 if there are no such element
     */
    public int indexOf(Object object) {
        checkSize();
        Node node = first;
        for (int i = 0; i < size; i++) {
            if (node.data == object) {
                return i;
            }
            node = node.next;
        }
        return -1;
    }

    /**
     * Retrieves and removes the head (first element) of this list.
     *
     * @return - element data that was in it
     */
    public T remove() {
        checkSize();
        Object element = first.data;
        first = first.next;
        first.setPrevLink(null);
        size--;

        return (T) element;
    }

    /**
     * Checks size (if it is correct)
     * @return - (true) correct / (false) incorrect
     */
    private boolean checkSize() {
        if (size != 0)
            return true;
        System.out.println("emptyList");
        System.exit(0);
        return false;

    }

    /**
     * Removes the element at the specified position in this list.
     *
     * @param index - index of specified element
     * @return - element data that was in it
     */
    public T remove(int index) {
        checkSize();
        checkIndex(index);

        Node node = first;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        Node prev = node.prev;
        Node next = node.next;

        prev.setNextLink(next);
        next.setPrevLink(prev);
        size--;
        return (T) node.data;
    }

    /**
     * Removes and returns the first element from this list.
     *
     * @return - element data that was in it
     */
    public T removeFirst() {
        checkSize();
        Node node = first;
        if (size > 1) {
            Node next = node.next;
            next.setPrevLink(null);
            first = next;
        }
        size--;
        return (T) node.data;
    }

    /**
     * Removes and returns the last element from this list.
     *
     * @return - element data that was in it
     */
    public T removeLast() {
        checkSize();
        Object element = null;
        if (size == 1) {
            element = first.data;
            first.setElement(null);
        } else if (size == 2) {
            element = last.data;
            last.setElement(null);
        } else if (size > 1) {
            element = last.data;
            Node prev = last.prev;
            prev.setNextLink(null);
            last = prev;
        }
        size--;
        return (T) element;
    }

    /**
     * Replaces the element at the specified
     * position in this list with the specified element.
     *
     * @param index - index of the specified element
     * @param element - element to what we want to change
     * @return - element data that was in it
     */
    public T set(int index, T element) {
        checkSize();
        checkIndex(index);
        Node node = first;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        Object prevElement = node.data;
        node.setElement(element);

        return (T) prevElement;
    }

    /**
     * Returns the number of elements in this list.
     *
     * @return - CustomLinkedList size
     */
    public int size() {
        return size;
    }

    /**
     * Returns an array containing all of the elements
     * in this list in proper sequence (from first to last element).
     *
     * @return - Object[] that include all elements
     */
    public Object[] toArray() {
        Object[] array = new Object[size];
        Node node = first;
        array[0] = node.data;
        for (int i = 1; i < size; i++) {
            node = node.next;
            array[i] = node.data;
        }
        return array;
    }

    /**
     * Node for CustomLinkedList
     */
    class Node {
        private Node next, prev;
        private Object data;

        Node(T data, Node next, Node prev) {
            this.data = data;
            this.next = next;
            this.prev = prev;
        }

        public void setNextLink(Node next) {
            this.next = next;
        }

        public void setPrevLink(Node prev) {
            this.prev = prev;
        }

        public void setElement(Object element) {
            data = element;
        }
    }
}
