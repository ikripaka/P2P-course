package com.shpp.p2p.cs.ikripaka.assignment16;

/**
 *  This programme contain 4 classes with Custom Collections:
 *
 */

public class Assignment16 {
    public static void main(String[] args){
        Tester tester = new Tester();
        /**
         * If you want to test
         * CustomArrayList - enter: 1
         * CustomLinkedList - enter: 2
         * CustomStack - enter: 3
         * CustomQueue - enter: 4
         */
        tester.test(2);
    }
}
