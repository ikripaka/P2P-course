package com.shpp.p2p.cs.ikripaka.assignment16;

/**
 *  Creates Collection (CustomStack)
 * @param <T> - Collection type
 */

public class CustomStack<T> {
    private Node head;
    private int size;

    CustomStack() {
        size = 0;
        head = null;
    }

    /**
     * Pushes an item onto the top of this stack.
     */
    public T push(T item) {
        head = new Node(item, head);
        size++;
        return item;
    }

    /**
     * Removes the object at the top of this stack and returns that
     * object as the value of this function.
     */
    public synchronized T pop() {
        if (size > 0) {
            Node next = head.next;
            Object data = head.data;
            head = next;
            size--;
            return (T) data;
        }
        System.err.println("EmptyStack");
        System.exit(0);
        return null;
    }

    /**
     * Looks at the object at the top of this stack without removing it
     * from the stack.
     */
    public synchronized T peek() {
        if (size > 0)
            return (T) head.data;

        System.err.println("EmptyStack");
        System.exit(0);
        return null;
    }

    /**
     * Tests if this stack is empty.
     */
    public boolean empty() {
        return size == 0;
    }

    /**
     * One node for Stack
     * Has one link to next element
     */
    class Node {
        private Node next;
        private Object data;

        Node(T data, Node prev) {
            this.data = data;
            next = prev;
        }
    }
}
