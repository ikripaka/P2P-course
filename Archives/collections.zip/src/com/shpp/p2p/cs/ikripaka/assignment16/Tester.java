package com.shpp.p2p.cs.ikripaka.assignment16;

import java.util.Arrays;

/**
 * Tests 4 collections:
 * CustomArrayList
 * CustomLinkedList
 * CustomStack
 * CustomQueue
 */
public class Tester {

    Tester() {
    }

    /**
     * Switches tests:
     * 1 - CustomArrayList
     * 2 - CustomLinkedList
     * 3 - CustomStack
     * 4 - CustomQueue
     * @param switcher - controls what collection programme should test
     */
    void test(int switcher) {
        switch (switcher) {
            case 1:
                testArrayList();
                break;
            case 2:
                testLinkedList();
                break;
            case 3:
                testStack();
                break;
            case 4:
                testQueue();
                break;
        }
    }

    /**
     * Tests CustomArrayList
     */
    private void testArrayList() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>();

        for (int i = 0; i < 27; i++) {
            char letter = (char) ('a' + i);
            customArrayList.add(letter);
        }
        System.out.println(Arrays.toString(customArrayList.toArray()));
        for (int i = customArrayList.size() / 2; i < customArrayList.size(); ) {
            customArrayList.remove(i);
        }
        System.out.println(Arrays.toString(customArrayList.toArray()));
        customArrayList.trimToSize();
        for (int i = 0; i < customArrayList.size(); i++) {
            char symbol = (char) ('0' + i);
            customArrayList.set(i, symbol);
        }
        System.out.println(Arrays.toString(customArrayList.toArray()));
        customArrayList.clear();
        customArrayList.trimToSize();
        if (customArrayList.isEmpty()) {
            customArrayList.add('A');
        }
        System.out.println(customArrayList.contains('o') ? "true" : "false");
        customArrayList.add('o');
        System.out.println(customArrayList.indexOf('0') + " 0 - " + customArrayList.indexOf('o') + " o");
    }

    /**
     * Tests CustomLinkedList
     */
    private void testLinkedList() {
        CustomLinkedList<Character> customLinkedList = new CustomLinkedList<>();
        System.out.println("- Add 26 letters: ");

        for (int i = 0; i < 26; i++) {
            char letter = (char) ('a' + i);
            System.out.print(letter + " ");
            customLinkedList.add(letter);
        }

        System.out.println();
        System.out.println("- Show conversion to array: " + Arrays.toString(customLinkedList.toArray()));
        System.out.println("- Delete first 13 letters: ");

        for (int i = 0; i < 13; i++) {
            System.out.print(customLinkedList.removeFirst() + " ");
        }

        System.out.println();
        System.out.println("- Delete 13 letters from the end: ");

        for (int i = 0; i < 13; i++) {
            System.out.print(customLinkedList.removeLast() + " ");
        }

        System.out.println();
        System.out.println("- Add 10 numbers in char alternately ( 1 - from the beginning, 2 - from the end) : ");
        System.out.println();

        for(int i = 0; i < 10; i++){
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            if(i % 2 == 0) {
                customLinkedList.addFirst(letter);
            }else{
                customLinkedList.addLast(letter);
            }
        }
        System.out.println("- Remove element with index 5:" + customLinkedList.remove(5));
        System.out.println("- Test contains method (contain '1'?) : " + customLinkedList.contains(1));

        System.out.println("- Remove remaining elements: ");
        while (!customLinkedList.isEmpty()){
            System.out.print(customLinkedList.remove() + " ");
        }


    }

    /**
     * Tests CustomStack
     */
    private void testStack() {
        CustomStack<Character> customStack = new CustomStack<>();

        System.out.println("- Push 27 letters: ");
        for (int i = 0; i < 27; i++) {
            char letter = (char) ('a' + i);
            customStack.push(letter);
        }

        System.out.println("- Pop 17 elements: ");
        for (int i = 0; i < 17; i++) {
            System.out.print(customStack.pop() + " ");
        }

        System.out.println("- Show peek: " + customStack.peek());
        System.out.println("- Push 10 numbers in char: ");
        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            customStack.push(letter);
        }

        System.out.println("- Show peek: " + customStack.peek());
        System.out.println("- Remove remaining elements: ");
        while (!customStack.empty()) {
            System.out.print(customStack.pop() + " ");
        }
    }

    /**
     * Tests CustomQueue
     */
    private void testQueue() {
        CustomQueue<Character> customQueue = new CustomQueue<>();

        System.out.println("- Add 27 letters: ");
        for (int i = 0; i < 27; i++) {
            char letter = (char) ('a' + i);
            customQueue.add(letter);
        }

        System.out.println("- Poll 17 elements: ");
        for (int i = 0; i < 17; i++) {
            System.out.print(customQueue.poll() + " ");
        }

        System.out.println("- Push 10 numbers in char: ");
        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            customQueue.add(letter);
        }

        System.out.println("- Show peek: " + customQueue.peek());
        System.out.println("- Remove remaining elements: ");
        while (!customQueue.empty()) {
            System.out.print(customQueue.poll() + " ");
        }
    }
}
