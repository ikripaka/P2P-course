package com.shpp.p2p.cs.ikripaka.assignment16;

import java.util.Arrays;

/**
 * Creates Collection (CustomArrayList)
 *
 * @param <T> - Collection type
 */
class CustomArrayList<T> {

    /**
     * Default initial capacity.
     */
    private static final int DEFAULT_CAPACITY = 10;
    /**
     * Shared empty array instance used for empty instances.
     */
    private static final Object[] EMPTY_ELEMENTDATA = {};
    /**
     * The array buffer into which the elements of the ArrayList are stored.
     * The capacity of the ArrayList is the length of this array buffer.
     */
    private Object[] elementData;
    /**
     * The size of the ArrayList (the number of elements it contains).
     */
    private int size;

    /**
     * Constructs an empty list with the specified initial capacity.
     *
     * @param initialCapacity - the initial capacity of the list
     */
    CustomArrayList(int initialCapacity) {
        if (initialCapacity > 0) {
            elementData = new Object[initialCapacity];
        } else if (initialCapacity == 0) {
            elementData = new Object[DEFAULT_CAPACITY];
        } else {
            System.err.println("Illegal Capacity: " + initialCapacity);
            System.exit(0);
        }
        size = 0;
    }

    /**
     * Constructs an empty list with an initial capacity of ten.
     */
    CustomArrayList() {
        size = 0;
        elementData = new Object[DEFAULT_CAPACITY];
    }

    /**
     * Increases the capacity of this {@code CustomArrayList} instance, if
     * necessary, to ensure that it can hold at least the number of elements
     * specified by the minimum capacity argument.
     *
     * @param minCapacity - the desired minimum capacity
     */
    private void ensureCapacity(int minCapacity) {
        if (minCapacity > elementData.length) {
            int newCapacity = (minCapacity * 3) / 2 + 1;
            Object[] newData = new Object[newCapacity];
            System.arraycopy(elementData, 0, newData, 0, elementData.length);
            elementData = newData;
        }
    }

    /**
     * Appends the specified element to the end of this list
     *
     * @param e - element to be appended to this list
     */
    public void add(T e) {
        ensureCapacity(size + 1);
        elementData[size] = e;
        size++;
    }

    /**
     * Inserts the specified element at the specified position in this list.
     * Shifts the element currently at that position (if any) and
     * any subsequent elements to the right (adds one to their indices).
     *
     * @param index   - index in which the specified element is to be inserted
     * @param element - element to be inserted
     */
    public void add(int index, T element) {
        checkIndex(index);
        ensureCapacity(size + 1);
        System.arraycopy(elementData, index, elementData, index + 1, size - index);
        elementData[index] = element;
        size++;
    }

    /**
     * Returns the size of elements in this list
     *
     * @return - the number of elements int this list
     */
    public int size() {
        return size;
    }

    /**
     * Replaces the element at the specified in the list with
     * the specified element
     *
     * @param index   - index of element to replace
     * @param element - element to be stored at the specified position
     * @return - the element previously at the specified position
     */
    public T set(int index, T element) {
        checkIndex(index);
        T prevElement = (T) elementData[index];
        elementData[index] = element;
        return prevElement;
    }

    /**
     * Returns if this list contains no elements
     *
     * @return - if this list contains no elements
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns an array containing all of the elements in this list
     * in proper sequence (from first to last element).
     *
     * @return - array with elements in proper sequence
     */
    public Object[] toArray() {
        return Arrays.copyOf(elementData, size);
    }

    /**
     * returns element in the specified position
     *
     * @param index - index of element to return
     * @return - the element at the specified position in this list
     */
    public Object get(int index) {
        checkIndex(index);
        return elementData[index];
    }

    /**
     * Checks index to correctness
     * (can exit from program)
     *
     * @param index
     */
    private void checkIndex(int index) {
        if (index < 0 || index >= elementData.length) {
            System.err.println("outOfBoundsCheckIndex: your index " + index +
                    " possible index from 0 ");
            System.exit(0);
        }
    }

    /**
     * Removes all of the elements from this list.  The list will
     * be empty after this call returns.
     */
    public void clear() {
        for (int i = 0; i < elementData.length; i++) {
            elementData[i] = null;
        }
        size = 0;
    }

    /**
     * Removes the element at the specified position in this list.
     * Shifts any subsequent elements to the left (subtracts one from their
     * indices).
     *
     * @param index - the index of the element to be removed
     * @return - the element that was removed from the list
     */
    public T remove(int index) {
        checkIndex(index);
        T oldValue = (T) elementData[index];
        System.arraycopy(elementData, index + 1, elementData, index - 1, size - index);
        elementData[size] = null;
        size--;
        return oldValue;
    }

    /**
     * Returns {@code true} if this list contains the specified element.
     * More formally, returns {@code true} if and only if this list contains
     * at least one element {@code e} such that
     * {@code Objects.equals(o, e)}.
     *
     * @param o - element whose presence in this list is to be tested
     * @return - (true)  if this list contains the specified element
     */
    public boolean contains(Object o) {
        return indexOf(o) >= 0;
    }

    /**
     * Returns the index of the first occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     * More formally, returns the lowest index {@code i} such that
     * {@code Objects.equals(o, get(i))},
     * or -1 if there is no such index.
     */
    public int indexOf(Object o) {
        return indexOfRange(o, 0, size);
    }

    /**
     * Checks if the specified object is in the list
     *
     * @param o     - specified element
     * @param start - position from which method starts checking
     * @param end   - position to which method ends checking
     * @return (true) the lowest index or -1
     */
    int indexOfRange(Object o, int start, int end) {
        Object[] arr = elementData;
        if (o == null) {
            for (int i = start; i < end; i++) {
                if (arr[i] == null) {
                    return i;
                }
            }
        } else {
            for (int i = start; i < end; i++) {
                if (o.equals(arr[i])) {
                    return i;
                }
            }
        }

        return -1;
    }

    /**
     * Trims the capacity of this {@code CustomArrayList} instance to be the
     * list's current size.
     */
    public void trimToSize() {
        if (size < elementData.length) {
            elementData = (size == 0) ? EMPTY_ELEMENTDATA : Arrays.copyOf(elementData, size);
        }
    }


}
