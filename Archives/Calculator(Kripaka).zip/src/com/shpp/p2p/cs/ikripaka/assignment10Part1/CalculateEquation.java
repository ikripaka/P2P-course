package com.shpp.p2p.cs.ikripaka.assignment10Part1;

/**
 * Calculates expression
 * It bases on RPN
 */

import java.util.*;
import java.util.regex.Matcher;

class CalculateEquation implements ArithmeticalOperationsConstants {
    private double result = 0;
    private LinkedList<String> dividedLine;
    private HashMap<String,Double> allVariables;

    //Constructor
    CalculateEquation(String RPNnote, HashMap<String, Double> variables) {
        dividedLine = fillLinkedListWithString(RPNnote.split(" "));
        allVariables = variables;
        calculate();
    }

    private void calculate() {
        double intermediateResult;

        // Calculate all expressions with FIRST_PRIORITY operator (^)
        for (int i = 0; i < dividedLine.size(); i++) {
            if (matches(dividedLine.get(i))) {
                intermediateResult = raiseToAPower(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                dividedLine.remove(i);
                dividedLine.remove(i - 1);
                dividedLine.set(i - 2, String.valueOf(intermediateResult));

                if(dividedLine.get(i-2).equals("Infinity")) try {
                    throw new Exception("Result is very big. Enter other Equation.");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                i -= 2;
            }
        }

        // Calculate all expressions with SECOND_PRIORITY operator (*, /)
        for(int i = 0; i < dividedLine.size(); i++){
            if(dividedLine.get(i).equals("*")){
                intermediateResult = multiply(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                dividedLine.remove(i);
                dividedLine.remove(i - 1);
                dividedLine.set(i - 2, String.valueOf(intermediateResult));

                if(dividedLine.get(i-2).equals("Infinity")) try {
                    throw new Exception("Result is very big. Enter other Equation.");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                i -= 2;
            }
            if(dividedLine.get(i).equals("/")){
                intermediateResult = divide(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                dividedLine.remove(i);
                dividedLine.remove(i - 1);
                dividedLine.set(i - 2, String.valueOf(intermediateResult));

                if(dividedLine.get(i-2).equals("Infinity")) try {
                    throw new Exception("Result is very big. Enter other Equation.");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                i -= 2;
            }
        }

        // Calculate all expressions with THIRD_PRIORITY operator (+, -)
        for(int i = 0; i < dividedLine.size(); i++){
            if(dividedLine.get(i).equals("+")){
                intermediateResult = plus(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                dividedLine.remove(i);
                dividedLine.remove(i - 1);
                dividedLine.set(i - 2, String.valueOf(intermediateResult));

                if(dividedLine.get(i-2).equals("Infinity")) try {
                    throw new Exception("Result is very big. Enter other Equation.");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                i -= 2;
            }
            if(dividedLine.get(i).equals("-")){
                intermediateResult = minus(Double.parseDouble(dividedLine.get(i - 2)), Double.parseDouble(dividedLine.get(i - 1)));
                dividedLine.remove(i);
                dividedLine.remove(i - 1);
                dividedLine.set(i - 2, String.valueOf(intermediateResult));

                if(dividedLine.get(i-2).equals("Infinity")) try {
                    throw new Exception("Result is very big. Enter other Equation.");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                i -= 2;
            }
        }
        result = Double.parseDouble(dividedLine.get(0));
    }

    /**
     * Records all data to LinkedList
     * @param array - splitted line
     * @return - LinkedList with divided information
     */
    private LinkedList<String> fillLinkedListWithString(String[] array) {
        LinkedList<String> list = new LinkedList();
        Collections.addAll(list, array);
        return list;
    }

    /**
     * Checks if the symbol - operator
     * @param symbols - one symbol in String
     * @return - true/false  if symbol matches
     */
    private boolean matches(String symbols) {
        Matcher match = ArithmeticalOperationsConstants.FIRST_PRIORITY.matcher(String.valueOf(symbols));
        return match.matches();
    }

    /**
     * Pluses two numbers
     * @param var1 - first number
     * @param var2 - second number
     * @return - adding two numbers
     */
    private double plus(double var1, double var2) {
        return var1 + var2;
    }

    /**
     * Minuses two numbers
     * @param var1 - first number
     * @param var2 - second number
     * @return - difference of two numbers
     */
    private double minus(double var1, double var2) {
        return var1 - var2;
    }

    /**
     * Multiply two numbers
     * @param var1 - first number
     * @param var2 - second number
     * @return - product of two numbers
     */
    private double multiply(double var1, double var2) {
        return var1 * var2;
    }

    /**
     * Divides two numbers
     * @param var1 - first number
     * @param var2 - second number
     * @return - share of two numbers
     */
    private double divide(double var1, double var2) {
        return var1 / var2;
    }

    /**
     * Raises to power var1 number in var2 power
     * @param var1 - number
     * @param var2 - power
     * @return - raise to power
     */
    private double raiseToAPower(double var1, double var2) {
        return Math.pow(var1, var2);
    }

    double getResult() {
        return result;
    }
}
