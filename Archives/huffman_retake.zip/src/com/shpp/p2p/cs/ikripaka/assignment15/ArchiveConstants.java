package com.shpp.p2p.cs.ikripaka.assignment15;

import java.util.regex.Pattern;

/**
 * This class in itself holds constants that program use
 */
public interface ArchiveConstants {

    // Determines archived file format
    Pattern ARCHIVED_FILE_INDICATOR = Pattern.compile("\\w+.par");

    // Determines archived file format
    Pattern UNARCHIVED_FILE_INDICATOR = Pattern.compile("\\w+.uar");

    // Determines valid file format
    Pattern FILE_INDICATOR = Pattern.compile("(\\w+\\.[a-z]{3,4})|(\\w+\\.[a-z]{2}[0-9])");

    // Determine valid filename
    Pattern VALID_FILENAME = Pattern.compile("[A-Z0-9a-z]+");

    // Default file that program archive
    String DEFAULT_FILE = "test.txt";

    int TABLE_LENGTH = 12;

    int BITS_IN_ONE_BYTE = 8;

    int BITS_TO_CODE_CHARACTER_REPETITION_COUNT = 4;

}