package com.shpp.p2p.cs.ikripaka.assignment15;

    /**
     * The main class
     * This program can:
     * - archive file in format (.par) using Huffman algorithm
     * - unpack file from (.par) to (.uar) using Huffman algorithm
     *
     * Class consist of main function that:
     * - controls program
     * - catches exceptions
     */

    public class Assignment15 {


        public static void main(String[] args) {
            try {
                ExtractFilename filename = new ExtractFilename(args);
                filename.extractFilename();
                double startTime = System.currentTimeMillis();
                if (!filename.isFileArchived() || args[0].equals("-a")) {
                    Archiver archiverFile = new Archiver(filename);
                    archiverFile.archive();
                    double timeSpent = (System.currentTimeMillis() - startTime) / 1000;
                    System.out.println("Time: " + timeSpent + "sec.");
                } else {
                    Unarchiver unarchiverFile = new Unarchiver(filename);
                    unarchiverFile.unzip();
                    double timeSpent = (System.currentTimeMillis() - startTime) / 1000;
                    System.out.println("Time: " + timeSpent + "sec.");
                }
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
    }

