package com.shpp.p2p.cs.ikripaka.assignment15;

import java.io.*;
import java.util.HashMap;

/**
 * This class can archive file into (.par) format
 * It works with String byte sequences
 */
class Archiver implements ArchiveConstants {
    // Contains filename of file
    private ExtractFilename filename;
    private double fileSizeBefore, fileSizeAfter;
    // Contains (key) byte cipher - (symbol count) symbol code
    private HashMap<Byte, Integer> symbolFrequency = new HashMap<>();
    // Contains (key) byte cipher - (symbol cipher in String) symbol code
    private HashMap<Byte, String> ciphersForSymbols = new HashMap<>();

    // CONSTRUCTOR
    Archiver(ExtractFilename startFilename) {
        filename = startFilename;
    }

    /**
     * Finds all symbols which are in the file
     * Creates symbol frequency
     *
     * @param file - string path to the file
     * @throws IOException
     */
    private byte[] findAllSymbols(String file) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        byte[] availableSymbols = new byte[reader.available()];
        reader.read(availableSymbols, 0, reader.available());
        reader.close();

        // fills in symbols and their frequencies to HashMap
        byte oneSymbol;
        for (int i = 0; i < availableSymbols.length; i++) {
            oneSymbol = availableSymbols[i];
            if (symbolFrequency.containsKey(oneSymbol)) {
                symbolFrequency.put(oneSymbol, (symbolFrequency.get(oneSymbol) + 1));
            } else {
                symbolFrequency.put(oneSymbol, 1);
            }
        }
        return availableSymbols;
    }

    /**
     * Archives file
     *
     * @param filenameForNewFile - filename for archived file
     * @throws IOException
     */
    private void archiveFile(String filenameForNewFile, byte[] buffer) throws IOException {
        FileOutputStream out = new FileOutputStream(filenameForNewFile + ".par");
        BufferedOutputStream writer = new BufferedOutputStream(out);

        int fileSize = (buffer.length);
        fileSizeBefore = fileSize;
        byte[] table = formTable(fileSize);
        writer.write(table);

        int filledBitsInBytes = 0;
        StringBuilder byteSequence;
        StringBuilder builder = new StringBuilder();


        for (int i = 0; i < fileSize; i++) {
            byte oneSymbolCode = buffer[i];
            byteSequence = new StringBuilder(ciphersForSymbols.get(oneSymbolCode));

            while (byteSequence.length() != 0) {
                builder.append(byteSequence.charAt(byteSequence.length() - 1));
                byteSequence.deleteCharAt(byteSequence.length() - 1);
                filledBitsInBytes++;

                if (i == buffer.length - 1 && filledBitsInBytes < BITS_IN_ONE_BYTE && byteSequence.length() == 0) {
                    while (filledBitsInBytes < BITS_IN_ONE_BYTE) {
                        builder.append("0");
                        filledBitsInBytes++;
                    }
                }
                if (filledBitsInBytes == BITS_IN_ONE_BYTE) {
                    filledBitsInBytes = 0;
                    String str = builder.toString();
                    byte lineInByte = (byte) Integer.parseInt(str, 2);
                    writer.write(lineInByte);
                    builder = new StringBuilder();
                }
            }
        }

        writer.flush();
        writer.close();

        File getFileSize = new File(filename.getFilename() + ".par");
        fileSizeAfter = (int) getFileSize.length();
    }

    /**
     * Forms table that consist of
     * - 4 bytes for length of association table
     * - 8 bytes for number of bytes of input file
     *
     * @param fileLength - file size
     * @return buffer -
     */
    private byte[] formTable(int fileLength) {
        byte[] buffer = new byte[TABLE_LENGTH + symbolFrequency.size() +
                symbolFrequency.size() * BITS_TO_CODE_CHARACTER_REPETITION_COUNT];
        int i = TABLE_LENGTH;
        i = writeNumberOfInputBytes(buffer, i, fileLength);
        writeTableSize(buffer, i);
        writeAssociationTable(buffer);

        return buffer;
    }

    /**
     * Writes number of input bytes in the table
     *
     * @param buffer - table
     * @param i      - counter
     * @param number - number that we should write in the table
     * @return - i(counter)
     */
    private int writeNumberOfInputBytes(byte[] buffer, int i, int number) {
        for (int counter = 0; counter < BITS_IN_ONE_BYTE; counter++) {
            buffer[i - 1] = (byte) (number % 100);
            number /= 100;
            i--;
        }
        return i;
    }

    /**
     * Writes association table size
     *
     * @param buffer - table
     * @param i      - counter
     */
    private void writeTableSize(byte[] buffer, int i) {
        int number;
        number = symbolFrequency.size() * (BITS_TO_CODE_CHARACTER_REPETITION_COUNT + 1);
        for (int counter = 0; counter < 4; counter++) {
            buffer[i - 1] = (byte) (number % 100);
            number /= 100;
            i--;
        }
    }

    /**
     * Writes association table
     * 1 byte - symbol
     * 4 byte - count
     *
     * @param buffer - table
     */
    private void writeAssociationTable(byte[] buffer) {
        int i = TABLE_LENGTH;
        for (Byte key : symbolFrequency.keySet()) {
            buffer[i] = key;
            for (int j = 4, number = symbolFrequency.get(key); j > 0; j--) {
                buffer[i + j] = (byte) (number % 100);
                number /= 100;
            }
            i += BITS_TO_CODE_CHARACTER_REPETITION_COUNT + 1;
        }
    }

    /**
     * Prints file size
     */
    private void printFileSize() {
        System.out.println("File size BEFORE: " + fileSizeBefore + " bytes ");
        System.out.println("File size AFTER: " + fileSizeAfter + " bytes ");
        System.out.println("Compression: " + fileSizeBefore / fileSizeAfter);
    }

    /**
     * Main method that makes archiving
     *
     * @throws IOException
     */
    void archive() throws IOException {
        byte[] allSymbols = findAllSymbols(filename.getFile());

        HuffmanTreeBuilder huffmanTreeBuilder = new HuffmanTreeBuilder(symbolFrequency);
        huffmanTreeBuilder.buildTree();
        fillInCiphersForSymbols(huffmanTreeBuilder.getCiphersForSymbols());

        archiveFile(filename.getFilename(), allSymbols);
        printFileSize();
    }

    /**
     * Fills in reverse byte sequence
     * @param ciphers - ciphers that coded by Huffman code
     */
    private void fillInCiphersForSymbols(HashMap<Byte, String> ciphers) {
        for(Byte key : ciphers.keySet()){
            ciphersForSymbols.put(key, new StringBuilder(ciphers.get(key)).reverse().toString());
        }
    }
}
