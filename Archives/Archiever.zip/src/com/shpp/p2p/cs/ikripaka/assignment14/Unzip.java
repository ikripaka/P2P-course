package com.shpp.p2p.cs.ikripaka.assignment14;

/**
 * This class unpacking archived file in (.uar) format
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

class Unzip implements ArchiveConstants {
    private ExtractFilename filename;
    private int numberOfBitsToEncryptOneCharacter;
    private HashMap<Byte, Integer> ciphersForSymbolInByte;
    private HashMap<String, Integer> ciphersForSymbolInString;
    private int bytesNumber, associationTableSize;
    private double fileSizeBefore, fileSizeAfter;

    //CONSTRUCTOR
    Unzip(ExtractFilename startFilename) throws IOException {
        filename = startFilename;
        ciphersForSymbolInString = new HashMap<>();
        ciphersForSymbolInByte = new HashMap<>();

        readTable(filename.getFile());
        calculateNumberOfBitsToEncryptOneCharacter();
        fillInStringByteCodeCombination();
        unzipFile(filename.getFile(), filename.getUnzipFilename());

        printTheFileSize();
    }

    /**
     * Prints information about file size
     */
    private void printTheFileSize() {
        System.out.println("File size BEFORE: " + fileSizeBefore + " bytes ");
        System.out.println("File size AFTER: " + fileSizeAfter + " bytes ");
    }

    /**
     * This function unpacks file
     * @param file - file path
     * @param filenameForNewFile - filename for unpacked file
     * @throws IOException
     */
    private void unzipFile(String file, String filenameForNewFile) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        FileOutputStream writer = new FileOutputStream(filenameForNewFile + ".uar");

        byte[] buffer = new byte[reader.available()];
        int bytesInFile = reader.available();
        reader.read(buffer, 0, bytesInFile);
        reader.close();

        fileSizeBefore = bytesInFile;

        int filledBitsInBytes = 0;
        StringBuilder builder = new StringBuilder();
        int filledBitsInBuilder = 0;
        StringBuilder oneByteCode;
        int byteCounter = 0;

        for (int i = TABLE_LENGTH + associationTableSize; i < bytesInFile; i++) {
            oneByteCode = extractByteCode(buffer[i]);

            while (oneByteCode.length() > 0 && byteCounter < bytesNumber) {
                if (filledBitsInBytes < 8) {
                    if (filledBitsInBuilder < numberOfBitsToEncryptOneCharacter) {
                        builder.append(oneByteCode.charAt(oneByteCode.length() - 1));
                        oneByteCode = oneByteCode.deleteCharAt(oneByteCode.length() - 1);
                        filledBitsInBuilder++;
                        filledBitsInBytes++;
                    } else {
                        writer.write(ciphersForSymbolInString.get(builder.toString()));
                        builder = new StringBuilder();
                        filledBitsInBuilder = 0;
                        byteCounter++;
                    }
                    if (filledBitsInBytes == 8) {
                        filledBitsInBytes = 0;
                        break;
                    }
                }
            }
        }
        writer.close();

        File getFileSize = new File(filename.getUnzipFilename()+".uar");
        fileSizeAfter = getFileSize.length();
    }

    /**
     * Determines byte code combination in string
     * @param number - the number which must be translated into a binary system of the number
     * @return - byte code (in string)
     */
    private StringBuilder extractByteCode(byte number) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < BITS_IN_ONE_BYTE; i++) {
            builder.append(number % 2 < 0 ? -(number % 2) : (number % 2));
            number /= 2;
        }
        return builder;
    }

    /**
     * Fills in string cipher for symbols
     */
    private void fillInStringByteCodeCombination() {
        String byteSequence;
        for (Byte key : ciphersForSymbolInByte.keySet()) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0, number = key; i < numberOfBitsToEncryptOneCharacter; i++) {
                builder.append(number % 2);
                number /= 2;
            }
            byteSequence = builder.toString();
            ciphersForSymbolInString.put(byteSequence, ciphersForSymbolInByte.get(key));
        }
    }

    /**
     * Calculates how many symbols wo should take to encrypt one character
     */
    private void calculateNumberOfBitsToEncryptOneCharacter() {
        int numberOfPossibleCombinations = 2;
        numberOfBitsToEncryptOneCharacter = 1;
        while (ciphersForSymbolInByte.size() > numberOfPossibleCombinations) {
            numberOfBitsToEncryptOneCharacter++;
            numberOfPossibleCombinations *= 2;
        }
    }

    /**
     * Reads table
     * @param file - path to the file
     * - 4 bytes for length of association table
     * - 8 bytes for number of bytes of input file
     * @throws IOException
     */
    private void readTable(String file) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        StringBuilder str = new StringBuilder();
        int i;

        for (i = 0; i < 4; i++) {
            String oneByte = String.valueOf(reader.read());
            if (!oneByte.equals("0")) {
                str.append(oneByte);
            }
        }
        associationTableSize = Integer.parseInt(str.toString()) * 2;
        str = new StringBuilder();
        for (i = 0; i < 8; i++) {
            String oneByte = String.valueOf(reader.read());
            if (!oneByte.equals("0")) {
                str.append(oneByte);
            }
        }
        bytesNumber = Integer.parseInt(str.toString());

        for (i = 12; i < associationTableSize + TABLE_LENGTH; i += 2) {
            int symbolCode = reader.read();
            int symbolCipher = reader.read();
            ciphersForSymbolInByte.put((byte) symbolCipher, symbolCode);
        }
        reader.close();
    }

}
