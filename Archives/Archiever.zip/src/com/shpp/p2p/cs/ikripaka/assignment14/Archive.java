package com.shpp.p2p.cs.ikripaka.assignment14;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

/**
 *  This class can archive file into (.par) format
 *  It works with String byte sequences
 */
class Archive implements ArchiveConstants {
    // Contains filename of file
    private ExtractFilename filename;
    private int numberOfBitsToEncryptOneCharacter;
    // Contains (key) byte cipher - (data) symbol code
    private HashMap<Byte, Integer> cipherForSymbolsInBytes;
    // Contains (key) String cipher - (data) symbol code
    private HashMap<Byte, String> cipherForSymbolsInString;
    private double fileSizeBefore, fileSizeAfter;

    // CONSTRUCTOR
    Archive(ExtractFilename startFilename) throws IOException {
        filename = startFilename;
        cipherForSymbolsInBytes = new HashMap<>();
        cipherForSymbolsInString = new HashMap<>();

        findAllSymbols(filename.getFile());
        fillInCipherForSymbols();
        calculateNumberOfBitsToEncryptOneCharacter();

        fillInStringByteCodeCombination();

        archiveFile(filename.getFile(), filename.getArchiveFilename());

        printTheFileSize();
    }


    /**
     * Calculates how many symbols wo should take to encrypt one character
     */
    private void calculateNumberOfBitsToEncryptOneCharacter() {
        int numberOfPossibleCombinations = 2;
        numberOfBitsToEncryptOneCharacter = 1;
        while (cipherForSymbolsInBytes.size() > numberOfPossibleCombinations) {
            numberOfBitsToEncryptOneCharacter++;
            numberOfPossibleCombinations *= 2;
        }
    }

    /**
     * Finds all symbols which are in the file
     * @param file - string path to the file
     * @throws IOException
     */
    private void findAllSymbols(String file) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        while (true) {
            byte oneSymbol = (byte) reader.read();
            if (oneSymbol == -1) {
                break;
            }
            cipherForSymbolsInBytes.put(oneSymbol, 0);
        }
        reader.close();
    }

    /**
     * Fills in ByteCode combination (in string) for all letters that encrypt them
     */
    private void fillInStringByteCodeCombination() {
        String byteSequence;
        for (Byte key : cipherForSymbolsInBytes.keySet()) {
            StringBuilder builder = new StringBuilder();
            for (int i = 0, number = cipherForSymbolsInBytes.get(key); i < numberOfBitsToEncryptOneCharacter; i++) {
                builder.append(number % 2);
                number /= 2;
            }
            byteSequence = builder.toString();
            cipherForSymbolsInString.put(key, byteSequence);
        }
    }

    /**
     * Fills in byte cipher for all symbols
     */
    private void fillInCipherForSymbols() {
        int i = 0;
        for (Byte key : cipherForSymbolsInBytes.keySet()) {
            cipherForSymbolsInBytes.put(key, i);
            i++;
        }

    }

    /**
     * Archives file
     * @param file - path to the file
     * @param archivedFilename - filename for archived file
     * @throws IOException
     */
    private void archiveFile(String file, String archivedFilename) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        FileOutputStream writer = new FileOutputStream(archivedFilename + ".par");


        int fileSize = (reader.available());
        fileSizeBefore = fileSize;
        byte[] table = formTable(fileSize);
        writer.write(table);

        byte[] buffer = new byte[fileSize];
        reader.read(buffer, 0, buffer.length);
        reader.close();

        int filledBitsInBytes = 0;
        String byteSequence;
        StringBuilder builder = new StringBuilder();
        String remainer = null;

        for (int i = 0; i < fileSize; i++) {
            byte oneSymbolCode = buffer[i];
            byteSequence = remainer == null ? cipherForSymbolsInString.get(oneSymbolCode) :
                    cipherForSymbolsInString.get(oneSymbolCode) + remainer;
            remainer = null;
            while (!byteSequence.isEmpty()) {
                if (filledBitsInBytes < 8) {
                    builder.append(byteSequence.charAt(byteSequence.length() - 1));
                    byteSequence = String.copyValueOf(byteSequence.toCharArray(), 0, byteSequence.length() - 1);
                    filledBitsInBytes++;

                    if (filledBitsInBytes == 8) {
                        filledBitsInBytes = 0;
                        String str = builder.toString();
                        byte lineInByte = (byte) Integer.parseInt(str, 2);
                        writer.write(lineInByte);
                        remainer = null;
                        builder = new StringBuilder();

                        if (!byteSequence.isEmpty()) {
                            remainer = byteSequence;
                            filledBitsInBytes = 0;
                            break;
                        }
                    }
                }
            }
        }

        if (remainer != null) {
            byte a = Byte.parseByte(remainer, 2);
            writer.write(a);
            filledBitsInBytes = 0;
        }
        if (filledBitsInBytes < 8 && filledBitsInBytes != 0) {
            String str = builder.toString();
            byte lineInByte = Byte.parseByte(str, 2);
            writer.write(lineInByte);
        }
        reader.close();
        writer.close();

        File getFileSize = new File(filename.getArchiveFilename() + ".par");
        fileSizeAfter = (getFileSize.length());

    }

    /**
     * Forms table that consist of
     * - 4 bytes for length of association table
     * - 8 bytes for number of bytes of input file
     * @param fileLength - file size
     * @return
     */
    private byte[] formTable(int fileLength) {
        byte[] buffer = new byte[12 + cipherForSymbolsInBytes.size() * 2];

        int i = 12;
        int number = fileLength;
        for (int counter = 0; counter < 8; counter++) {
            buffer[i - 1] = (byte) (number % 100);
            number /= 100;
            i--;
        }
        number = cipherForSymbolsInBytes.size();
        for (int counter = 0; counter < 4; counter++) {
            buffer[i - 1] = (byte) (number % 100);
            number /= 100;
            i--;
        }

        i = 12;

        for (Byte key : cipherForSymbolsInBytes.keySet()) {
            buffer[i] = key;
            buffer[i + 1] = cipherForSymbolsInBytes.get(key).byteValue();
            i += 2;
        }

        return buffer;
    }

    /**
     * Prints file size
     */
    private void printTheFileSize() {
        System.out.println("File size BEFORE: " + fileSizeBefore + " bytes ");
        System.out.println("File size AFTER: " + fileSizeAfter + " bytes ");
        System.out.println("Compression: " + fileSizeBefore / fileSizeAfter + " %");
    }

}
