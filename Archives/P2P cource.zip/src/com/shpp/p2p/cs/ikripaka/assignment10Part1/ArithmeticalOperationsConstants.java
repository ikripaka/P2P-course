package com.shpp.p2p.cs.ikripaka.assignment10Part1;

import java.util.regex.Pattern;

/**
 * Interface consists of the constants which is using in the classes
 */
public interface ArithmeticalOperationsConstants {

    Pattern NUMBER = Pattern.compile("[0-9 | .]");
    Pattern LETTERS = Pattern.compile("[a-z]");

    Pattern ALL_ARITHMETICAL_OPERATIONS = Pattern.compile("['^'|'*'|'/'|'+'|-]");
    Pattern FIRST_PRIORITY = Pattern.compile("['^']");
    Pattern SECOND_PRIORITY = Pattern.compile("[*|/]");
    Pattern THIRD_PRIORITY = Pattern.compile("[+|-]");
}
