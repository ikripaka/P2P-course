package com.shpp.p2p.cs.ikripaka.assignment10Part1;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Divides line with equation to note in RPN
 */
class ParseInputData implements ArithmeticalOperationsConstants {
    private StringBuilder parsedLine = new StringBuilder();
    private char[] lineWithEquation;

    // Constructor
    ParseInputData(String startLine) {
        lineWithEquation = startLine.toCharArray();
        divideLine();
    }

    /**
     * Gets parsed line
     *
     * @return - parsed line
     */
    String getParsedLine() {
        return parsedLine.toString();
    }

    /**
     * Divides line into RPN
     */
    private void divideLine() {
        ArrayList<Character> operationStack = new ArrayList<>();
        int length = lineWithEquation.length;
        System.out.println(lineWithEquation);

        // Runs over all symbols
        for (int i = 0; i < length; i++) {

            // if symbol - number
            if (matches(lineWithEquation[i], NUMBER)) {
                parsedLine.append(lineWithEquation[i]);

            }

            // if symbol - letter
            if (matches(lineWithEquation[i], LETTERS)) {
                parsedLine.append(lineWithEquation[i]);
            }

            // if symbol - arithmetical operation
            if (matches(lineWithEquation[i], ALL_ARITHMETICAL_OPERATIONS)) {

                parsedLine.append(' ');

                // if user print negative number
                if ((i > 1 && lineWithEquation[i] == '-' && matches(lineWithEquation[i - 1], ALL_ARITHMETICAL_OPERATIONS))
                        || (i == 0 && matches(lineWithEquation[i + 1], NUMBER))
                        || (i == 0 && matches(lineWithEquation[i + 1], LETTERS))) {
                    parsedLine.append('-');
                    continue;
                }

                //if (operation in stack = ^) and (current operation in line = ^)
                if (operationStack.size() >= 1 && matches(operationStack.get(operationStack.size() - 1), FIRST_PRIORITY)
                        && matches(lineWithEquation[i], FIRST_PRIORITY)) {
                    operationStack.add(lineWithEquation[i]);
                    continue;
                }

                // if (operation from stack prioritise >= prioritise of current symbol from line)
                if (operationStack.size() >= 1 && prioritize(operationStack.get(operationStack.size() - 1)) >= prioritize(lineWithEquation[i])) {

                    parsedLine.append(operationStack.get(operationStack.size() - 1));
                    operationStack.remove(operationStack.size() - 1);
                    parsedLine.append(' ');

                    // Forces out all symbols if (operation from stack priority > current operation in line)
                    for (int j = operationStack.size() - 1; operationStack.size() >= 1 && prioritize(operationStack.get(j)) >= prioritize(lineWithEquation[i]); j--) {
                        parsedLine.append(operationStack.get(j));
                        parsedLine.append(' ');
                        operationStack.remove(j);
                    }

                    operationStack.add(lineWithEquation[i]);
                } else {
                    operationStack.add(lineWithEquation[i]);
                }

            }

        }
        // Forced out all remaining operations
        int size = operationStack.size();
        for (int i = 0; i < size; i++) {
            parsedLine.append(' ');
            parsedLine.append(operationStack.get(operationStack.size() - 1));
            operationStack.remove(operationStack.size() - 1);
        }

    }

    /**
     * Compares symbol with Patterns
     *
     * @param symbol  - char symbol
     * @param pattern - pattern which we must use
     * @return - true/false if symbol matches
     */
    private boolean matches(char symbol, Pattern pattern) {
        Matcher match = pattern.matcher(String.valueOf(symbol));
        return match.matches();
    }

    /**
     * Determine what prioritise in arithmetical operation
     *
     * @param operation - arithmetical operation
     * @return - number of operation priority
     */
    private int prioritize(char operation) {
        Matcher match = FIRST_PRIORITY.matcher(String.valueOf(operation));
        if (match.matches()) {
            return 3;
        }

        match = SECOND_PRIORITY.matcher((String.valueOf(operation)));
        if (match.matches()) {
            return 2;
        }

        return 1;
    }
}
