package com.shpp.p2p.cs.ikripaka.assignment10Part1;

import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Matcher;

/**
 * -------- CALCULATOR --------
 * This class calculates expressions
 * which can contain these symbols:
 * ^, *, /, +, -
 * It bases on the ReversePolishNotation
 */

/**
 * !!!! WARNING !!!!
 *  * I didn`t do expressions with variables!!!!
 */
public class Calculator implements ArithmeticalOperationsConstants {
    public static void main(String[] args) {
        try {
            HashMap<String, Double> variables = new HashMap<>();
            if (args[0] == null) throw new Exception("The line is empty");

            variables = fillInVariablesInHashMap(args, variables);

            ParseInputData divideLine = new ParseInputData(args[0]);
            String RPNNote = divideLine.getParsedLine();
            System.out.println(RPNNote);

            CalculateEquation calculate = new CalculateEquation(RPNNote, variables);
            System.out.println(calculate.getResult());

        } catch (Exception e) {
            System.err.println("Incorrect equation");
            System.out.println(Arrays.toString(e.getStackTrace()));
        }

    }

    /**
     * Fills HashMap with arrays and numeric numbers
     *
     * @param args      - input String array
     * @param variables - HashMam which holds all variables and their numeric value
     */
    private static HashMap<String, Double> fillInVariablesInHashMap(String[] args, HashMap<String, Double> variables) throws Exception {
        Matcher match;
        if (args.length > 1) {
            for (int i = 1; i < args.length; i++) {
                String letter[] = args[i].split("=");
                match = LETTERS.matcher(letter[0]);
                if (letter[0].length() > 1 || !match.matches()) {
                    throw new Exception("Incorrect VARIABLES");
                }
                variables.put(letter[0], Double.valueOf(letter[1]));
            }
        }
        return variables;
    }
}
