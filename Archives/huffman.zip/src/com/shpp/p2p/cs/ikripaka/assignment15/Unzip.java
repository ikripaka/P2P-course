package com.shpp.p2p.cs.ikripaka.assignment15;

/**
 * This class unpacking archived file in (.uar) format
 */

import java.io.*;
import java.util.HashMap;
import java.util.PriorityQueue;

class Unzip implements ArchiveConstants {
    // Contains filename of file
    private ExtractFilename filename;
    // Contains (key) byte cipher - (symbol count) symbol code
    private HashMap<Byte, Integer> symbolFrequency;
    // Contains (key) String cipher - (symbol byte code) symbol code
    private HashMap<String, Integer> ciphersForSymbols;
    private PriorityQueue<Node> priorityQueue = new PriorityQueue<>();
    private CodeSaver codeSaver = new CodeSaver();
    private int bytesNumber, associationTableSize;
    private double fileSizeBefore, fileSizeAfter;

    //CONSTRUCTOR
    Unzip(ExtractFilename startFilename) {
        filename = startFilename;
        ciphersForSymbols = new HashMap<>();
        symbolFrequency = new HashMap<>();
    }

    /**
     * Prints information about file size
     */
    private void printTheFileSize() {
        System.out.println("File size BEFORE: " + fileSizeBefore + " bytes ");
        System.out.println("File size AFTER: " + fileSizeAfter + " bytes ");
    }

    /**
     * This function unpacks file
     *
     * @param filenameForNewFile - filename for unpacked file
     * @param buffer             - array with all symbols from the file
     * @throws IOException
     */
    private void unzipFile(String filenameForNewFile, byte[] buffer) throws IOException {
        FileOutputStream out = new FileOutputStream(filenameForNewFile + ".uar");
        BufferedOutputStream writer = new BufferedOutputStream(out);

        int bytesInFile = buffer.length;

        fileSizeBefore = bytesInFile;

        StringBuilder builder = new StringBuilder();
        StringBuilder oneByteCode;
        int byteCounter = 0;

        for (int i = TABLE_LENGTH + associationTableSize; i < bytesInFile; i++) {
            oneByteCode = extractByteCode(buffer[i] < 0 ? (256 - Math.abs(buffer[i])) : buffer[i]);

            while (oneByteCode.length() != 0) {
                if (ciphersForSymbols.containsKey(builder.toString())) {
                    builder = new StringBuilder();
                }
                while (!ciphersForSymbols.containsKey(builder.toString()) && oneByteCode.length() != 0) {
                    builder.append(oneByteCode.charAt(oneByteCode.length() - 1));
                    oneByteCode.deleteCharAt(oneByteCode.length() - 1);
                }
                if (ciphersForSymbols.containsKey(builder.toString())) {
                    writer.write(ciphersForSymbols.get(builder.toString()));
                    byteCounter++;

                    if (byteCounter == bytesNumber) break;
                }
            }
        }
        writer.flush();
        writer.close();

        File getFileSize = new File(filename.getFilename() + ".uar");
        fileSizeAfter = getFileSize.length();
    }

    /**
     * Determines byte code combination in string
     *
     * @param number - the number which must be translated into a binary system of the number
     * @return - byte code (in string)
     */
    private StringBuilder extractByteCode(int number) {
        StringBuilder builder = new StringBuilder();
        while (number != 0) {
            builder.append(number % 2);
            number /= 2;
        }
        while (builder.length() < BITS_IN_ONE_BYTE) {
            builder.append("0", 0, 1);
        }
        return builder;
    }

    /**
     * Creates Huffman tree and
     * builds code for symbols
     */
    private void createHuffmanTree() {
        HuffmanTree huffmanTree = new HuffmanTree(symbolFrequency, priorityQueue, codeSaver);
        huffmanTree.buildTree();
        codeSaver = huffmanTree.getCodeSaver();
        priorityQueue = huffmanTree.getPriorityQueue();
        Node root = priorityQueue.poll();
        if (root != null) {
            if (symbolFrequency.size() == 1) {
                root.buildCode("0");
            } else {
                root.buildCode("");
            }
        }
    }

    /**
     * Fills in string byte code to the HashMap
     */
    private void fillInCipherForSymbols() {
        for (Byte key : codeSaver.getCipherForSymbol().keySet()) {
            char c = Character.toString(key).charAt(0);
            System.out.println(c + ": " + codeSaver.getCipherForSymbol().get(key));
            ciphersForSymbols.put(codeSaver.getCipherForSymbol().get(key), Integer.valueOf(key));
        }
    }

    /**
     * Reads table
     *
     * @param file - path to the file
     *             - 4 bytes for length of association table
     *             - 8 bytes for number of bytes of input file
     * @throws IOException
     */
    private byte[] readTable(String file) throws IOException {
        FileInputStream reader = new FileInputStream(file);
        byte[] allSymbolsFromFile = new byte[reader.available()];
        reader.read(allSymbolsFromFile, 0, reader.available());
        reader.close();

        StringBuilder str = new StringBuilder();

        readTableSize(allSymbolsFromFile, str);
        associationTableSize = Integer.parseInt(str.toString());

        str = readNumberOfInputBytes(allSymbolsFromFile);
        bytesNumber = Integer.parseInt(str.toString());

        readAssociationTable(allSymbolsFromFile);
        return allSymbolsFromFile;
    }

    /**
     * Reads association table
     * - 1 byte - symbol byte code
     * - 4 bytes - symbol count
     *
     * @param allSymbols - array with all symbols from the file
     * @throws IOException
     */
    private void readAssociationTable(byte[] allSymbols) {
        for (int i = TABLE_LENGTH; i < associationTableSize + TABLE_LENGTH; i += 5) {
            int symbolCode = allSymbols[i];
            StringBuilder builder = new StringBuilder();
            for (int j = 1; j < 5; j++) {
                if (allSymbols[i + j] != 0) {
                    builder.append(allSymbols[i + j]);
                }
            }
            int numberOfTheSameCharacters = Integer.parseInt(builder.toString());
            symbolFrequency.put((byte) symbolCode, numberOfTheSameCharacters);
        }
        System.out.println();
    }

    /**
     * Reads number of input bytes
     *
     * @param allSymbols - byte array which contain all symbols from the file
     * @return - string with number of input bytes
     * @throws IOException
     */
    private StringBuilder readNumberOfInputBytes(byte[] allSymbols) {
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < BITS_IN_ONE_BYTE; i++) {
            String oneByte = String.valueOf(allSymbols[i]);
            if (!oneByte.equals("0")) {
                str.append(oneByte);
            }
        }
        return str;
    }

    /**
     * Reads table size
     *
     * @param allSymbols - byte array which contain
     * @param str        - String Builder which fills with table size
     * @throws IOException
     */
    private void readTableSize(byte[] allSymbols, StringBuilder str) {
        for (int i = 0; i < 4; i++) {
            String oneByte = String.valueOf(allSymbols[i]);
            if (!oneByte.equals("0")) {
                str.append(oneByte);
            }
        }
    }

    /**
     * Main method that unzip file
     *
     * @throws IOException
     */
    void unzip() throws IOException {
        byte[] buffer = readTable(filename.getFile());
        createHuffmanTree();
        fillInCipherForSymbols();
        unzipFile(filename.getFilename(), buffer);

        printTheFileSize();
    }

}
