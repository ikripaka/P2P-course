package com.shpp.p2p.cs.ikripaka.assignment15;

import java.util.HashMap;
import java.util.PriorityQueue;

/**
 * HuffmanTree build huffman tree using:
 * - PriorityQueue
 * - CodeSaver
 * - Node
 * - InternalNode
 * - LeafNode
 */

class HuffmanTree {
    private HashMap<Byte, Integer> symbolFrequency;
    private PriorityQueue<Node> priorityQueue;
    private CodeSaver codeSaver;

    /**
     * Constructor
     * @param symbolFrequency - symbol frequency in the file
     * @param priorityQueue - queue that sorted from largest to smallest
     * @param codeSaver - saves information about code of the symbol
     */
    HuffmanTree(HashMap<Byte, Integer> symbolFrequency, PriorityQueue<Node> priorityQueue, CodeSaver codeSaver) {
        this.symbolFrequency = symbolFrequency;
        this.priorityQueue = priorityQueue;
        this.codeSaver = codeSaver;
    }

    /**
     * Builds Huffman tree
     */
    void buildTree(){
        fillInPriorityQueue();
        createAssociationTree();
    }

    /**
     * Fills in priorityQueue with symbolFrequency
     */
    private void fillInPriorityQueue() {
        for (Byte key : symbolFrequency.keySet()) {
            priorityQueue.add(new LeafNode(key, symbolFrequency.get(key), codeSaver));
        }
    }

    /**
     * Creates association tree
     */
    private void createAssociationTree() {
        int sum = 0;
        while (priorityQueue.size() > 1) {
            Node first = priorityQueue.poll();
            Node second = priorityQueue.poll();
            InternalNode node = new InternalNode(first, second);
            sum += node.sum;
            priorityQueue.add(node);
        }
        System.out.println("sum of elements: " + sum);
        System.out.println("size: " + priorityQueue.size());
    }

    PriorityQueue<Node> getPriorityQueue() {
        return priorityQueue;
    }

    CodeSaver getCodeSaver() {
        return codeSaver;
    }
}
