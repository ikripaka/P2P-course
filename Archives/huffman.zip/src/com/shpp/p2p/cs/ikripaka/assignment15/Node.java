package com.shpp.p2p.cs.ikripaka.assignment15;

/**
 * Node is using as basis of the Huffman tree
 */

public class Node implements Comparable<Node> {
    final int sum;
    String code;

    /**
     * Assigns symbol cipher code to the array
     * @param code - symbol cioher
     */
    void buildCode(String code){
        this.code = code;
    }

    /**
     * Creates Node
     * @param sum - symbol count
     */
    Node(int sum) {
        this.sum = sum;
    }

    /**
     * Compares two Nodes
     * @param o - second node
     * @return - boolean array
     */
    @Override
    public int compareTo(Node o) {
        return Integer.compare(sum, o.sum);
    }
}
