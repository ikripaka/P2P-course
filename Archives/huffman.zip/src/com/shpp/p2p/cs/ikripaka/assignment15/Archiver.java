package com.shpp.p2p.cs.ikripaka.assignment15;

    /**
     * The main class
     * This program can:
     * - archive file in format (.par) using Huffman algorithm
     * - unpack file from (.par) to (.uar) using Huffman algorithm
     *
     * Class consist of main function that:
     * - controls program
     * - catches exceptions
     */

    public class Archiver {


        public static void main(String[] args) {
            try {
                ExtractFilename filename = new ExtractFilename(args);
                filename.extractFilename();
                double startTime = System.currentTimeMillis();
                if (!filename.isFileArchived() || args[0].equals("-a")) {
                    Archive archiveFile = new Archive(filename);
                    archiveFile.archive();
                    double timeSpent = (System.currentTimeMillis() - startTime) / 1000;
                    System.out.println("Time: " + timeSpent + "sec.");
                } else {
                    Unzip unzipFile = new Unzip(filename);
                    unzipFile.unzip();
                    double timeSpent = (System.currentTimeMillis() - startTime) / 1000;
                    System.out.println("Time: " + timeSpent + "sec.");
                }
            } catch (Exception e) {
                System.err.println(e.getMessage());
                e.printStackTrace();
            }
        }
    }

