package com.shpp.p2p.cs.ikripaka.assignment15;

/**
 * LeafNode is the main Node that has
 * information about the symbol(cipher, count)
 */

class LeafNode extends Node {
    private byte symbol;
    private CodeSaver codeSaver;

    /**
     * Creates LeafNode
     * @param symbol - symbol byte code
     * @param count - symbol count
     * @param codeSaver - saves information about symbols(symbol, code)
     */
    LeafNode(Byte symbol, int count, CodeSaver codeSaver) {
        super(count);
        this.symbol = symbol;
        this.codeSaver = codeSaver;
    }

    /**
     * Finishes symbol cipher formation
     * @param code - cipher for symbol
     */
    @Override
    void buildCode(String code) {
        super.buildCode(code);
        codeSaver.add(symbol, code);
    }
}
