package com.shpp.p2p.cs.ikripaka.assignment15;

/**
 * InternalNode is Node that has two links
 * to the right and left Nodes
 */

class InternalNode extends Node {
    private Node left, right;

    /**
     * Builds cipher for symbol
     * @param code - cipher for symbol
     */
    @Override
    void buildCode(String code){
        super.buildCode(code);
        left.buildCode(code + "0");
        right.buildCode(code + "1");
    }

    /**
     * Creates InternalNode
     * @param left - left link to the next Node
     * @param right - right link to the next Node
     */
    InternalNode(Node left, Node right) {
        super(left.sum + right.sum);
        this.left = left;
        this.right = right;
    }
}
