package com.shpp.p2p.cs.ikripaka.assignment15;

import java.util.HashMap;

/**
 * CodeSaver saves code to the symbols
 * moving along Huffman tree
 */
class CodeSaver {
    private HashMap<Byte, String> cipherForSymbol;

    // Constructor
    CodeSaver() {
        cipherForSymbol = new HashMap<>();
    }

    /**
     * Adds one more (symbol - code) to the HashMap
     * @param symbol - symbol byte code
     * @param code - code that defines Huffman tree
     */
    void add(byte symbol, String code) {
        cipherForSymbol.put(symbol, code);
    }

    HashMap<Byte, String> getCipherForSymbol() {
        return cipherForSymbol;
    }
}
