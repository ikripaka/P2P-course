package com.shpp.p2p.cs.ikripaka.assignment12;

import acm.graphics.GImage;
import java.util.LinkedList;
import java.util.Stack;

class FindSilhouettes implements SilhouettesConstants {
    private int silhouettes = 0;
    private int[][] pixels;
    private int[][] imageModel;
    private LinkedList<Integer> allSilhouettes;
    private int numOfRecursion = 0;
    private double averageValue;
    private int height, width;

    // true - average font value higher than HALF_OF_THE_MAX_COLOUR_VALUE
    // false - average font value lower than HALF_OF_THE_MAX_COLOUR_VALUE
    private boolean fontIndicator = true;

    // CONSTRUCTOR
    FindSilhouettes(int[][] startPixels, int pictureHeight, int pictureWidth) {
        pixels = startPixels;
        width = pictureWidth;
        height = pictureHeight;
        allSilhouettes = new LinkedList<Integer>();

        findAverageValue();

        // if (font is brighter than silhouette)
        if (averageValue < HALF_OF_THE_MAX_COLOUR_VALUE) {
            fontIndicator = false;
        }

        separateTheBackgroundFromTheSilhouette();
        findSilhouettes();
        wasteGarbage();
    }

    /**
     * Separates the background from the silhouettes
     * returns - imageModel thad filled with (0 and 1)
     * 0 - font
     * 1 - silhouette
     */
    private void separateTheBackgroundFromTheSilhouette() {
        imageModel = new int[width][height];

        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {
                if (fontIndicator) {

                    if (extractColorValues(pixels[col][row]) < HALF_OF_THE_MAX_COLOUR_VALUE) {
                        imageModel[col][row] = 1;
                    } else if (extractColorValues(pixels[col][row]) >= HALF_OF_THE_MAX_COLOUR_VALUE) {
                        imageModel[col][row] = 0;
                    }

                } else {

                    if (extractColorValues(pixels[col][row]) > HALF_OF_THE_MAX_COLOUR_VALUE) {
                        imageModel[col][row] = 1;
                    } else if (extractColorValues(pixels[col][row]) <= HALF_OF_THE_MAX_COLOUR_VALUE) {
                        imageModel[col][row] = 0;
                    }
                }

            }
        }
    }

    /**
     * Finds average font value
     * returns - averageValue
     */
    private void findAverageValue() {
        int numOfPixels = 0;
        int numbersSum = 0;

        for (int col = 0; col < width; col++) {
            numbersSum += extractColorValues(pixels[col][0]);
            numbersSum += extractColorValues(pixels[col][height - 1]);
            numOfPixels += 2;
        }
        averageValue = numbersSum / numOfPixels;
    }

    /**
     * Finds silhouettes
     * returns - allSilhouettes filled with all silhouettes from the image
     */
    private void findSilhouettes() {
        Stack<String> stack = new Stack<String>();
        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {

                if (imageModel[col][row] == 2 || imageModel[col][row] == 0) { // if(pixel - font)
                    continue;
                }
                if (imageModel[col][row] == 1) { // if(pixel - silhouette)
                    stack.add(row + "_" + col);
                    depthSearch(stack, row, col, 0);
                    allSilhouettes.add(numOfRecursion);
                    numOfRecursion = 0;
                }
            }
        }
    }

    /**
     * Finds all silhouette pixels
     * @param stack - stack with link to the points
     * @param row - row number
     * @param col - col number
     * @param numOfRecursions - number of the recursions (shows them how much a violet silhouette)
     */
    private void depthSearch(Stack<String> stack, int row, int col, int numOfRecursions) {
        if (!stack.isEmpty()) {

            if (row < height - 1 && imageModel[col][row + 1] == 1) { // bottom pixel \/
                imageModel[col][row + 1] = 2;
                stack.add((row + 1) + "_" + col);
                numOfRecursions++;
                depthSearch(stack, row, col, numOfRecursions);

            } else if (row >= 1 && imageModel[col][row - 1] == 1) { // upper pixel /\
                imageModel[col][row - 1] = 2;
                stack.add((row - 1) + "_" + col);
                numOfRecursions++;
                depthSearch(stack, row, col, numOfRecursions);

            } else if (col >= 1 && imageModel[col - 1][row] == 1) { // left pixel <
                imageModel[col - 1][row] = 2;
                stack.add(row + "_" + (col - 1));
                numOfRecursions++;
                depthSearch(stack, row, col, numOfRecursions);

            } else if (col < width - 1 && imageModel[col + 1][row] == 1) { // right pixel >
                imageModel[col + 1][row] = 2;
                stack.add(row + "_" + (col + 1));
                numOfRecursions++;
                depthSearch(stack, row, col, numOfRecursions);

            } else {
                String[] splittedLine = stack.peek().split("_");
                stack.remove(stack.peek());
                row = Integer.parseInt(splittedLine[0]);
                col = Integer.parseInt(splittedLine[1]);
                depthSearch(stack, row, col, numOfRecursions);

            }
        }

        if (numOfRecursion == 0) {
            numOfRecursion = numOfRecursions;
        }
    }

    /**
     * Wastes garbage
     * returns - number of the silhouettes
     */
    private void wasteGarbage() {
        int maxValueIndex = 0;

        // finds max recursion value
        for (int i = 0; i < allSilhouettes.size(); i++) {
            if (allSilhouettes.get(i) > allSilhouettes.get(maxValueIndex)) {
                maxValueIndex = i;
            }
        }

        int percentagePart = (int) (allSilhouettes.get(maxValueIndex) * ENTRY_THRESHOLD);

        // finds silhouettes
        for (Integer allSilhouette : allSilhouettes) {
            if (allSilhouette > percentagePart) {
                silhouettes++;
            }
        }
    }

    /**
     * Extracts color value from the pixel
     * returns - sum of all components (red / green / blue)
     */
    private double extractColorValues(int pixel) {
        int red = GImage.getRed(pixel);
        int green = GImage.getGreen(pixel);
        int blue = GImage.getBlue(pixel);

        return (red + green + blue) / 3;
    }

    int getSilhouettes() {
        return silhouettes;
    }
}
