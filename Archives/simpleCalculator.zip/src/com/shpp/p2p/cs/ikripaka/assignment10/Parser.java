package com.shpp.p2p.cs.ikripaka.assignment10;

import java.util.Stack;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Divides line with equation to note in RPN
 */
class Parser implements Constants {
    private StringBuilder parsedLine = new StringBuilder();

    Parser(String startLine) {
        divideLine(startLine);
    }

    /**
     * Gets parsed line
     *
     * @return - parsed line
     */
    String getParsedLine() {
        return parsedLine.toString();
    }

    /**
     * Divides line into RPN
     */
    private void divideLine(String line) {
        Stack<String> stack = new Stack<>();
        StringTokenizer tokenizer = new StringTokenizer(line, "/*^()-+", true);
        String currentToken = null, prevToken;

        // Runs over all symbols
        while (tokenizer.hasMoreTokens()) {
            prevToken = currentToken;
            currentToken = tokenizer.nextToken();

            // if one token - number or letter
            if (matches(currentToken, NUMBER) || matches(currentToken, LETTERS)) {
                parsedLine.append(currentToken).append(" ");
                continue;
            }

            // if one token - "("
            if (currentToken.equals("(")) {
                stack.push(currentToken);
                continue;
            }

            //if one token - ")"
            if (currentToken.equals(")")) {
                while (!stack.peek().equals("(")) {
                    parsedLine.append(stack.pop()).append(" ");
                }
                stack.pop();
                continue;
            }

            // if one token - arithmetical operation
            if (matches(currentToken, ALL_ARITHMETICAL_OPERATIONS)) {

                // if minus at the beginning of the line or minus situated after bracket "("
                if((prevToken == null && currentToken.equals("-"))
                        || (prevToken != null && prevToken.equals("(") && currentToken.equals("-"))){
                    parsedLine.append("0").append(" ");
                    stack.push("-");
                    continue;
                }

                // if previous operation and current are "^"
                if(!stack.empty() && stack.peek().equals("^") && currentToken.equals("^")){
                    stack.push(currentToken);
                    continue;
                }

                // if previous operation has higher priority thar current
                while (!stack.empty() && (prioritize(stack.peek()) > prioritize(currentToken)
                        || prioritize(stack.peek()) == prioritize(currentToken))) {
                    parsedLine.append(stack.pop()).append(" ");
                }
                stack.push(currentToken);
            }
        }

        // Forced out all remaining operations
        while(!stack.empty()) {
            parsedLine.append(stack.peek());
            if(!stack.empty()) parsedLine.append(" ");
            stack.remove(stack.peek());
        }
    }

    /**
     * Compares symbol with Patterns
     *
     * @param symbol  - char symbol
     * @param pattern - pattern which we must use
     * @return - true/false if symbol matches
     */
    private boolean matches(String symbol, Pattern pattern) {
        Matcher match = pattern.matcher(String.valueOf(symbol));
        return match.matches();
    }

    /**
     * Determine what prioritise in arithmetical operation
     *
     * @param operation - arithmetical operation
     * @return - number of operation priority
     */
    private int prioritize(String operation) {
        Matcher match = FIRST_PRIORITY.matcher(operation);
        if (match.matches()) {
            return 3;
        }

        match = SECOND_PRIORITY.matcher(operation);
        if (match.matches()) {
            return 2;
        }

        match = THIRD_PRIORITY.matcher(operation);
        if (match.matches()) {
            return 1;
        }
        return 0;
    }
}
