package com.shpp.p2p.cs.ikripaka.assignment10;

/**
 * Calculates expression
 * - that written on RPN
 * - from left side to right side
 *
 */

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class CalculateExpression implements Constants {
    private double result = 0;
    /**
     * Contains line that divided by " "
     */
    private LinkedList<String> dividedLine;
    /**
     * Contains variables that user wrote
     */
    private HashMap<String, Double> allVariables;

    /**
     * Constructs
     * @param RPNNote
     * @param variables
     */
    CalculateExpression(String RPNNote, HashMap<String, Double> variables) {
        allVariables = variables;
        dividedLine  = replaceArraysWithNumbers(fillLinkedListWithString(RPNNote.split(" ")));
    }

    /**
     * Replaces arrays (letters) with numbers corresponding to variable value
     * @param list - divided line
     * @return - line without arrays
     */
    private LinkedList<String> replaceArraysWithNumbers(LinkedList<String> list) {
        for (int i = 0; i < list.size(); i++) {
            if (matches(list.get(i), LETTERS)) {
                list.set(i, allVariables.get(list.get(i)).toString());
            }
        }
        return list;
    }


    /**
     * Calculates expression from left side to right one
     */
     void calculate() {
        double intermediateResult = 0;

        // Go through all line
        for (int i = 0; i < dividedLine.size(); i++) {
            try {
                // Do arithmetical operation
                if (matches(dividedLine.get(i), ALL_ARITHMETICAL_OPERATIONS)) {
                    switch (dividedLine.get(i)) {
                        case "^":
                            intermediateResult = raiseToAPower(Double.parseDouble(dividedLine.get(i - 2)),
                                    Double.parseDouble(dividedLine.get(i - 1)));
                            break;
                        case "*":
                            intermediateResult = multiply(Double.parseDouble(dividedLine.get(i - 2)),
                                    Double.parseDouble(dividedLine.get(i - 1)));
                            break;
                        case "/":

                            intermediateResult = divide(Double.parseDouble(dividedLine.get(i - 2)),
                                    Double.parseDouble(dividedLine.get(i - 1)));
                            break;
                        case "+":
                            intermediateResult = plus(Double.parseDouble(dividedLine.get(i - 2)),
                                    Double.parseDouble(dividedLine.get(i - 1)));
                            break;
                        case "-":
                            intermediateResult = minus(Double.parseDouble(dividedLine.get(i - 2)),
                                    Double.parseDouble(dividedLine.get(i - 1)));
                            break;
                    }
                    dividedLine.remove(i);
                    dividedLine.remove(i - 1);
                    dividedLine.set(i - 2, String.valueOf(intermediateResult));
                    i -= 2;
                }

            } catch (Exception e) {
                System.err.println("There are some troubles with the calculation");
                e.printStackTrace();
                System.out.println(e.getMessage());
                System.exit(0);
            }
        }

        if (!dividedLine.get(0).equals("")) {
            result = Double.valueOf(dividedLine.get(0));
        } else if (dividedLine.size() > 1) {
            result = Double.valueOf(dividedLine.get(1));
        }
    }

    /**
     * Records all data to LinkedList
     *
     * @param array - splitted line
     * @return - LinkedList with divided information
     */
    private LinkedList<String> fillLinkedListWithString(String[] array) {
        LinkedList<String> list = new LinkedList<>();
        Collections.addAll(list, array);
        return list;
    }

    /**
     * Checks if the symbol - operator
     *
     * @param symbols - one symbol in String
     * @return - true/false  if symbol matches
     */
    private boolean matches(String symbols, Pattern pattern) {
        Matcher match = pattern.matcher(String.valueOf(symbols));
        return match.matches();
    }

    /**
     * Pluses two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - adding two numbers
     */
    private double plus(double var1, double var2) {
        return var1 + var2;
    }

    /**
     * Minuses two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - difference of two numbers
     */
    private double minus(double var1, double var2) {
        return var1 - var2;
    }

    /**
     * Multiply two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - product of two numbers
     */
    private double multiply(double var1, double var2) {
        return var1 * var2;
    }

    /**
     * Divides two numbers
     *
     * @param var1 - first number
     * @param var2 - second number
     * @return - share of two numbers
     */
    private double divide(double var1, double var2) {
        if(var2 == 0){
            System.err.println("Can't divide by zero");
            System.exit(0);
        }
        return var1 / var2;
    }

    /**
     * Raises to power var1 number in var2 power
     *
     * @param var1 - number
     * @param var2 - power
     * @return - raise to power
     */
    private double raiseToAPower(double var1, double var2) {
        return Math.pow(var1, var2);
    }

    double getResult() {
        return result;
    }
}
