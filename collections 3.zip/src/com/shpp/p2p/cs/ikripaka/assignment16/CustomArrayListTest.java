package com.shpp.p2p.cs.ikripaka.assignment16;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;

public class CustomArrayListTest {

    @Test
    public void clear() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(2);
        System.out.println("- Add 10 numbers: ");

        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customArrayList.add(letter);
        }
        customArrayList.remove(5);
        customArrayList.trimToSize();
        customArrayList.clear();
        Assert.assertSame(0, customArrayList.size());
    }

    @Test
    public void contains() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(2);
        System.out.println("- Add 10 numbers: ");

        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customArrayList.add(letter);
        }
        customArrayList.remove(1);
        Assert.assertFalse(customArrayList.contains('1'));
    }

    @Test
    public void indexOf() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(2);
        System.out.println("- Add 10 numbers: ");

        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customArrayList.add(letter);
        }
        Assert.assertSame(5, customArrayList.indexOf('4'));
    }

    @Test
    public void isEmpty() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(2);
        System.out.println("- Add 10 numbers: ");

        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customArrayList.add(letter);
        }
        customArrayList.clear();
        customArrayList.trimToSize();
        Assert.assertTrue(customArrayList.isEmpty());
    }

    @Test
    public void set() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(2);
        System.out.println("- Add 10 numbers: ");

        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customArrayList.add(letter);
        }
        customArrayList.set(4, 'I');
        Assert.assertSame('I', customArrayList.get(4));
    }

    @Test
    public void size() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(20);
        System.out.println("- Add 2 numbers: ");

        for (int i = 0; i < 2; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customArrayList.add(letter);
        }
        customArrayList.trimToSize();
        Assert.assertSame(2, customArrayList.size());
    }

    @Test
    public void toArray() {
        CustomArrayList<Character> customArrayList = new CustomArrayList<>(5);
        System.out.println("- Add 5 numbers: ");

        char[] actual = new char[5];
        for (int i = 0; i < 5; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            actual[i] = letter;
            customArrayList.add(letter);
        }
        Assert.assertArrayEquals(new char[]{'0','1','2','3','4'}, actual);

    }

    @Test
    public void generalTest(){
        CustomArrayList<Character> customArrayList = new CustomArrayList<>();

        for (int i = 0; i < 27; i++) {
            char letter = (char) ('a' + i);
            customArrayList.add(letter);
        }
        System.out.println(Arrays.toString(customArrayList.toArray()));

        System.out.println(customArrayList.indexOf('f'));

        System.out.println("foreach");
        for(char symbol: customArrayList){
            System.out.print(symbol + " ");
        }

        System.out.println("Delete half of the ArrayList data");
        for (int i = customArrayList.size() / 2; i < customArrayList.size(); ) {
            customArrayList.remove(i);
        }
        System.out.println(Arrays.toString(customArrayList.toArray()));
        customArrayList.trimToSize();
        for (int i = 0; i < customArrayList.size(); i++) {
            char symbol = (char) ('0' + i);
            customArrayList.set(i, symbol);
        }
        System.out.println(Arrays.toString(customArrayList.toArray()));
        customArrayList.clear();
        customArrayList.trimToSize();
        Assert.assertSame(0, customArrayList.size());
    }
}