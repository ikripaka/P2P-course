package com.shpp.p2p.cs.ikripaka.assignment16;

import org.junit.Assert;

/**
 * Tests CustomStack
 */
public class CustomStackTest {
    @org.junit.Test
    public void testAddingAndPolling() {
        CustomStack<Character> customStack = new CustomStack<>();

        System.out.println("- Add 27 letters: ");
        for (int i = 0; i < 27; i++) {
            char letter = (char) ('a' + i);
            customStack.push(letter);
        }

        System.out.println("- Poll 17 elements: ");
        char[] actual = new char[17];
        for (int i = 0; i < 17; i++) {
            char oneLetter = customStack.pop();
            actual[i] = oneLetter;
            System.out.print(oneLetter + " ");
        }
        char[] expected = new char[]{'{', 'z', 'y', 'x', 'w', 'v', 'u', 't', 's', 'r', 'q', 'p', 'o', 'n', 'm', 'l', 'k'};
        Assert.assertArrayEquals(expected, actual);
    }

    @org.junit.Test
    public void testPeek() {
        CustomStack<Character> customQueue = new CustomStack<>();

        System.out.println("- Add 10 numbers: ");
        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customQueue.push(letter);
        }
        System.out.println("Peek " + customQueue.peek());

        Assert.assertSame("Peek: ", '9', customQueue.peek());
    }

    @org.junit.Test
    public void testRemoving() {
        CustomStack<Character> customQueue = new CustomStack<>();
        char[] expected, actual;
        System.out.println("- Add 10 numbers: ");
        for (int i = 0; i < 10; i++) {
            char letter = (char) ('0' + i);
            System.out.print(letter + " ");
            customQueue.push(letter);
        }
        for (int i = 0; i < 5; i++) {
            customQueue.pop();
        }

        expected = new char[]{'4', '3', '2', '1', '0'};
        actual = new char[5];

        System.out.println();
        System.out.println("Items are not deleted: ");
        for (int i = 0; i < 5; i++) {
            char oneLetter = customQueue.pop();
            actual[i] = oneLetter;
            System.out.print(oneLetter + " ");
        }
        Assert.assertArrayEquals(expected, actual);
    }

    @org.junit.Test
    public void testForEmpty() {
        CustomStack<Character> customQueue = new CustomStack<>();
        Assert.assertTrue(customQueue.empty());
    }
}