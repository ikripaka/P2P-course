package com.shpp.p2p.cs.ikripaka.assignment16;

/**
 * Creates Collection(CustomLinkedList)
 *
 * @param <T> - Collection type
 */
class CustomLinkedList<T> {
    private Node first, last;
    private int size = 0;

    /**
     * Appends the specified element to the end of this list.
     *
     * @param element - element that appends
     * @return - (true) element appends successful
     */
    synchronized void add(T element) {
        if (size == 0) {
            first = new Node(element, null, null);
        } else if (size == 1) {
            last = new Node(element, null, first);
            first.setNextLink(last);
        } else if (size > 1) {
            Node newNode = new Node(element, null, last);
            last.setNextLink(newNode);
            last = newNode;
        }
        size++;
    }

    /**
     * Inserts the specified element at the beginning of this list.
     *
     * @param element - element that inserts
     */
    void addFirst(T element) {
        if (size == 0) {
            first = new Node(element, null, null);
        } else if (size == 1) {
            last = first;
            first = new Node(element, last, null);
            last.setPrevLink(first);
        } else if (size > 1) {
            Node newNode = new Node(element, first, null);
            first.setPrevLink(newNode);
            first = newNode;
        }
        size++;
    }

    /**
     * Whether or not list is found
     *
     * @return - (true) - empty/(false) - filled with element(s)
     */
    boolean isEmpty() {
        return size == 0;
    }

    /**
     * Appends the specified element to the end of this list.
     *
     * @param element - ellement that appends ti the end
     */
    void addLast(T element) {
        if (size == 0) {
            first = new Node(element, null, null);
        } else if (size == 1) {
            last = new Node(element, null, first);
            first.setNextLink(last);
        } else if (size > 1) {
            Node newNode = new Node(element, null, last);
            last.setNextLink(newNode);
            last = newNode;
        }
        size++;
    }

    /**
     * Removes all of the elements from this list.
     */
    void clear() {
        size = 0;
        first = null;
        last = null;
    }

    /**
     * Returns the element at the specified position in this list.
     *
     * @param index - index of element
     * @return - element data at the specified position
     */
    T get(int index) {
        checkIndex(index);
        checkSize();
        Node node = first;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        return (T) node.data;
    }

    /**
     * Checks index (if it correct)
     *
     * @param index - current index
     */
    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            System.err.println("outOfBoundsCheckIndex: your index " + index +
                    " possible index from 0 ");
            System.exit(0);
        }
    }

    /**
     * Returns the first element in this list.
     *
     * @return - first element in this list
     */
    T getFirst() {
        if (checkSize())
            return (T) first.data;

        System.out.println("outOfBoundsException");
        System.exit(0);
        return null;
    }

    /**
     * Returns the last element in this list.
     *
     * @return - last element in this list
     */
    T getLast() {
        if (checkSize())
            return (T) last.data;

        System.out.println("outOfBoundsException");
        System.exit(0);
        return null;
    }

    /**
     * Returns true if this list contains the specified element.
     *
     * @param element - el to be searched
     * @return - (true) if el is in the list
     */
    boolean contains(Object element) {
        return findValueIndex(element, first, 0) != -1;
    }

    /**
     * Returns the index of the first occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     *
     * @param element - element that function search
     * @return - index of element of -1 if there are no such element
     */
    int indexOf(Object element) {
        return findValueIndex(element, first, 0);
    }

    /**
     * Searches for object o index in the array
     *
     * @param o       - object that user want to find
     * @param counter
     * @return - (any number > 0) if el is here / (-1) if el isn't in the array
     */
    private int findValueIndex(Object o, Node node, int counter) {

        if (o == node.data) {
            return counter;
        } else if (node.next != null) {
            return findValueIndex(o, node.next, ++counter);
        }

        return -1;
    }

    /**
     * Retrieves and removes the head (first element) of this list.
     *
     * @return - element data that was in it
     */
    T remove() {
        checkSize();
        Object element = null;
        if (size == 1) {
            element = first.data;
            first = last;
        } else if (size == 2) {
            element = first.data;
            first = last;
            first.setPrevLink(null);
            last = null;
        } else if (size > 2) {
            element = first.data;
            first = first.next;
        }
        size--;
        return (T) element;
    }

    /**
     * Removes the element at the specified position in this list.
     *
     * @param index - index of specified element
     * @return - element data that was in it
     */
    T remove(int index) {
        checkSize();
        checkIndex(index);
        Node node = first;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        T element = (T) node.data;
        node.next.setPrevLink(node.prev);
        node.prev.setNextLink(node.next);
        size--;
        return element;
    }

    /**
     * Checks size (if it is correct)
     *
     * @return - (true) correct / (false) incorrect
     */
    private boolean checkSize() {
        if (size != 0)
            return true;
        System.out.println("empty List");
        System.exit(0);
        return false;

    }

    /**
     * Removes and returns the first element from this list.
     *
     * @return - element data that was in it
     */
    T removeFirst() {
        return remove();
    }

    /**
     * Removes and returns the last element from this list.
     *
     * @return - element data that was in it
     */
    T removeLast() {
        T element = (T) last.data;
        last = last.prev;;
        last.setNextLink(null);

        return element;
    }

    /**
     * Replaces the element at the specified
     * position in this list with the specified element.
     *
     * @param index   - index of the specified element
     * @param element - element to what we want to change
     * @return - element data that was in it
     */
    T set(int index, T element) {
        checkIndex(index);
        checkSize();
        Node node = first;
        for (int i = 0; i < index; i++) {
            node = node.next;
        }
        T prevElement = (T) node.data;
        node.data = element;
        return prevElement;
    }

    /**
     * Returns the number of elements in this list.
     *
     * @return - CustomLinkedList size
     */
    int size() {
        return size;
    }

    /**
     * Returns an array containing all of the elements
     * in this list in proper sequence (from first to last element).
     *
     * @return - Object[] that include all elements
     */
    Object[] toArray() {
        Object[] array = new Object[size];
        Node node = first;
        for (int i = 0; i < size; i++) {
            array[i] = node.data;
            node = node.next;
        }
        return array;
    }

    /**
     * Node for CustomLinkedList
     */
    class Node {
        private Node next, prev;
        private Object data;

        Node(T data, Node next, Node prev) {
            this.data = data;
            this.next = next;
            this.prev = prev;
        }

        void setNextLink(Node next) {
            this.next = next;
        }

        void setPrevLink(Node prev) {
            this.prev = prev;
        }
    }


}
