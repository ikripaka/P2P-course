package com.shpp.p2p.cs.ikripaka.assignment16;

/**
 * Creates Collection (CustomStack)
 *
 * @param <T> - Collection type
 */

class CustomStack<T> {
    private Node head = null;
    private int size = 0;

    /**
     * Pushes an item onto the top of this stack.
     */
    synchronized T push(T item) {
        head = new Node(item, head);
        size++;
        return item;
    }

    /**
     * Removes the object at the top of this stack and returns that
     * object as the value of this function.
     */
    synchronized T pop() {
        if (size > 0) {
            Node next = head.next;
            Object data = head.data;
            head = next;
            size--;
            return (T) data;
        }
        System.err.println("EmptyStack");
        System.exit(0);
        return null;
    }

    /**
     * Looks at the object at the top of this stack without removing it
     * from the stack.
     */
    synchronized T peek() {
        if (size > 0)
            return (T) head.data;

        System.err.println("EmptyStack");
        System.exit(0);
        return null;
    }

    /**
     * Tests if this stack is empty.
     */
    boolean empty() {
        return size == 0;
    }

    /**
     * One node for Stack
     * Has one link to next element
     */
    class Node {
        private Node next;
        private Object data;

        Node(T data, Node prev) {
            this.data = data;
            next = prev;
        }
    }
}
